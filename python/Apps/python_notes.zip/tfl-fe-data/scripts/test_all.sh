#!/usr/bin/env bash


.venv/Scripts/pytest -m "not integration"
.venv/Scripts/pytest -m integration

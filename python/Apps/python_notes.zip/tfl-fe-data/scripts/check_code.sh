#!/usr/bin/env bash

./.venv/Scripts/pytest -q
./.venv/Scripts/ruff check .
./.venv/Scripts/ruff format . --check
./.venv/Scripts/mypy src
./.venv/Scripts/mypy tests


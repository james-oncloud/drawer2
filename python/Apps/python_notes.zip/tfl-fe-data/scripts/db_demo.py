"""Runnable demo for MySQL abstraction layer."""
from datetime import datetime

from tfl.aws.mysql.config import MySQLConfig
from tfl.aws.mysql.mysql_client import MySQLClient, MySQLConnection
from tfl.aws.mysql.repository import BaseRepository


def main() -> None:
    now = datetime.now().strftime("%Y-%m-%d-%H%M%S")

    config = MySQLConfig.MySQLConfigBuilder().build()
    connection = MySQLConnection(config)
    client = MySQLClient(connection)
    users = BaseRepository(client, "users")

    print("Connected. Running demo operations...")

    next_id = users.count() + 1
    created_id = users.insert({"id": next_id, "name": "Alice Example", "email": f"alice@example-{now}.com"})
    print(f"Inserted user id: {created_id}")

    user = users.get_by_id(created_id)
    print(f"Fetched by id: {user}")

    users.update(created_id, {"name": "Alice Updated"})
    updated = users.get_by_id(created_id)
    print(f"After update: {updated}")

    total = users.count()
    print(f"Total users: {total}")

    # users.delete(created_id)
    # print(f"Deleted user id: {created_id}")

    client.close()
    print("Demo complete.")


if __name__ == "__main__":
    main()
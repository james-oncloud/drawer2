#!/usr/bin/env bash

./.venv/Scripts/pip install testcontainers[localstack] boto3 pytest



import json
from dataclasses import dataclass, field, asdict

def main():
    @dataclass(frozen=True)
    class ValidationError:
        field: str
        message: str

    @dataclass(frozen=True)
    class ValidationResult:
        is_valid: bool = True
        errors: list[ValidationError] = field(default_factory=list)

    # Example usage
    result = ValidationResult(
        is_valid=False,
        errors=[ValidationError(field="name", message="Required")]
    )

    myList = []
    myList.append(result)
    json_str = json.dumps([asdict(item) for item in myList])
    # json_str = json.dumps(asdict(myList))
    # json_str = json.dumps(asdict(result))
    print(json_str)

if __name__ == "__main__":
    raise SystemExit(main())

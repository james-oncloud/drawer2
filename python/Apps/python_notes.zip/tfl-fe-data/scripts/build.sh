#!/usr/bin/env bash

rm -rf dist
python -m build
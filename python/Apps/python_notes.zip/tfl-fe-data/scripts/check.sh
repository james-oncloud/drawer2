#!/usr/bin/env bash


.venv/Scripts/pytest -q
.venv/Scripts/ruff check .
.venv/Scripts/ruff format . --check
.venv/Scripts/ruff format src tests
.venv/Scripts/mypy src

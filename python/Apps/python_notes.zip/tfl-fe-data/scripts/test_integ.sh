#!/usr/bin/env bash


.venv/Scripts/pytest -m integration

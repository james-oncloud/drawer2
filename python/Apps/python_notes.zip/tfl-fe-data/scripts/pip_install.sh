#!/usr/bin/env bash

./.venv/Scripts/pip install -e .

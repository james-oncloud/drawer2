#!/bin/bash

# Fail if no commit message
if [ -z "$1" ]; then
  echo "Error: Commit message missing."
  echo "Usage: $0 \"your commit message\""
  exit 1
fi

COMMIT_MSG="$1"

echo "====== GIT STATUS ======"
git status
echo "========================="

# Confirm continue
read -p "Proceed with git add + commit? (y/n): " CONFIRM1
if [[ "$CONFIRM1" != "y" && "$CONFIRM1" != "Y" ]]; then
  echo "Aborted."
  exit 0
fi

echo "Adding files..."
git add .

echo "Committing with message: $COMMIT_MSG"
git commit -m "$COMMIT_MSG"

# Confirm push
read -p "Push to remote? (y/n): " CONFIRM2
if [[ "$CONFIRM2" != "y" && "$CONFIRM2" != "Y" ]]; then
  echo "Push cancelled."
  exit 0
fi

echo "Pushing..."
git push

echo "Done."
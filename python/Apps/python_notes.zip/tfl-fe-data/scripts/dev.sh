#!/usr/bin/env bash
set -euo pipefail

rm -rf .venv
python3 -m venv .venv
#.venv/Scripts/python -m pip install --upgrade certifi
source .venv/Scripts/activate
.venv/Scripts/python -m pip install -U pip
.venv/Scripts/python -m pip install -e ".[dev]"

.venv/Scripts/pip install boto3-stubs[s3]

.venv/Scripts/pytest -q
.venv/Scripts/ruff check .
.venv/Scripts/ruff format . --check
.venv/Scripts/ruff format src tests
.venv/Scripts/mypy src

./scripts/test_all.sh

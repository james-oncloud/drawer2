#!/usr/bin/env python3
"""
Simple, reliable Lambda package builder with timestamp.

Creates a ZIP with:
- Your source code from src/tfl/
- External dependencies from pyproject.toml ([project].dependencies)
- Timestamp in filename

boto3 is NOT included (pre-installed in AWS Lambda)

Usage:
    python scripts/build_zip.py
    python scripts/build_zip.py --list
"""

import os
import shutil
import subprocess
import sys
import tomllib
import zipfile
from datetime import datetime
from pathlib import Path


def build_lambda_package(
    pyproject_file: str = "pyproject.toml",
    source_dir: str = "src",
    package_name: str = "tfl"
) -> str:
    """
    Build Lambda deployment package with clean source code.

    Returns:
        Path to created ZIP file
    """

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    output_zip = f"tfl_fe_data_lambda_deployment_{timestamp}.zip"

    print("=" * 80)
    print("AWS Lambda Package Builder")
    print("=" * 80)
    print()
    print(f"Timestamp: {timestamp}")
    print(f"Output ZIP: {output_zip}")
    print()

    # Create temporary build directory
    build_dir = Path("_lambda_build_temp")
    if build_dir.exists():
        shutil.rmtree(build_dir)
    build_dir.mkdir()

    try:
        # Step 1: Copy source code
        print("Step 1: Copying source code...")
        src_path = Path(source_dir) / package_name
        dest_path = build_dir / package_name

        if not src_path.exists():
            print(f"ERROR: {src_path} not found!")
            return ""

        shutil.copytree(src_path, dest_path, ignore=shutil.ignore_patterns('__pycache__', '.pytest_cache', '.mypy_cache', '*.pyc'))
        print(f"[OK] Copied: {package_name}/")

        # Step 2: Install external dependencies (if any)
        print()
        print("Step 2: Installing external dependencies...")
        print("        (excluding boto3; pre-installed in Lambda runtime)")

        pyproject_path = Path(pyproject_file)
        if pyproject_path.exists():
            with open(pyproject_path, "rb") as f:
                pyproject_data = tomllib.load(f)

            dependencies = pyproject_data.get("project", {}).get("dependencies", []) or []
            dependencies = [dep.strip() for dep in dependencies if dep and dep.strip()]

            # Exclude boto3 from the deployment package.
            filtered_deps = []
            for dep in dependencies:
                dep_name = dep.split(";", 1)[0].strip().lower()
                if dep_name.startswith("boto3"):
                    continue
                filtered_deps.append(dep)

            if filtered_deps:
                print(f"   Found dependencies in {pyproject_file}: {', '.join(filtered_deps)}")
                result = subprocess.run(
                    [sys.executable, "-m", "pip", "install",
                     *filtered_deps,
                     "-t", str(build_dir),
                     "--quiet"],
                    capture_output=True,
                    text=True
                )
                if result.returncode == 0:
                    print("[OK] Dependencies installed")
                else:
                    print(f"[WARN] Failed to install: {result.stderr}")
            else:
                print(f"[OK] No external dependencies to install from {pyproject_file}")
        else:
            print(f"[OK] No {pyproject_file} file (no external dependencies)")

        # Step 3: Create ZIP file
        print()
        print("Step 3: Creating ZIP file...")

        file_count = 0
        with zipfile.ZipFile(output_zip, 'w', zipfile.ZIP_DEFLATED) as zipf:
            for root, dirs, files in os.walk(build_dir):
                for file in files:
                    # Skip compiled files and hidden files
                    if file.endswith(('.pyc', '.pyo')):
                        continue
                    if file.startswith('.'):
                        continue

                    filepath = Path(root) / file
                    # Check if file is in cache directories
                    if '__pycache__' in str(filepath) or '.pytest_cache' in str(filepath) or '.mypy_cache' in str(filepath):
                        continue

                    arcname = filepath.relative_to(build_dir)
                    zipf.write(str(filepath), str(arcname))
                    file_count += 1

        # Step 4: Verify and report
        size_bytes = Path(output_zip).stat().st_size
        size_kb = size_bytes / 1024
        size_mb = size_bytes / (1024 * 1024)

        print()
        print("=" * 80)
        print(f"[OK] SUCCESS! Package created")
        print("=" * 80)
        print(f"  Filename: {output_zip}")
        print(f"  Size: {size_mb:.2f} MB ({size_kb:.0f} KB)")
        print(f"  Files: {file_count}")
        print(f"  Handler: tfl.handler.lambda_handler")
        print("=" * 80)

        # Size warnings
        if size_bytes > 52428800:  # 50 MB
            print()
            print("[WARN] Exceeds 50 MB ZIP limit!")
            print("   Options: Use Lambda Layers or Container Images")
        elif size_kb > 10240:  # 10 MB
            print()
            print("[WARN] >10 MB package may have slower cold starts")

        print()
        print("DEPLOYMENT COMMANDS:")
        print("-" * 80)
        print()
        print("1. Update existing function:")
        print(f"   aws lambda update-function-code \\")
        print(f"     --function-name tfl-fe-data \\")
        print(f"     --zip-file fileb://{output_zip} \\")
        print(f"     --region eu-west-2")
        print()
        print("2. Create new function:")
        print(f"   aws lambda create-function \\")
        print(f"     --function-name tfl-fe-data \\")
        print(f"     --runtime python3.11 \\")
        print(f"     --role arn:aws:iam::YOUR_ACCOUNT:role/lambda-role \\")
        print(f"     --handler tfl.handler.lambda_handler \\")
        print(f"     --zip-file fileb://{output_zip} \\")
        print(f"     --region eu-west-2")
        print()
        print("3. Verify contents:")
        print(f"   python -m zipfile -l {output_zip}")
        print()

        return output_zip

    finally:
        # Cleanup
        if build_dir.exists():
            shutil.rmtree(build_dir)


def list_packages():
    """List all timestamped packages."""
    import glob

    files = sorted(
        glob.glob("lambda_deployment_*.zip"),
        key=lambda x: Path(x).stat().st_mtime,
        reverse=True
    )[:5]

    if files:
        print()
        print("Recent packages:")
        print("-" * 80)
        for f in files:
            size_mb = Path(f).stat().st_size / (1024 * 1024)
            print(f"  {f:<50} {size_mb:>6.2f} MB")
        print("-" * 80)


if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "--list":
        list_packages()
    else:
        zip_file = build_lambda_package()
        if zip_file:
            list_packages()


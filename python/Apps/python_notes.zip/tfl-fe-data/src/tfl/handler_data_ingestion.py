from __future__ import annotations

import os

from tfl.aws.mysql.mysql_client import get_connection
from tfl.aws.s3.paths import S3Paths
from tfl.aws.s3.s3_store import create_boto3_s3_store
from tfl.health_check.health_check_module import health_check_secrets_manager, health_check_s3, health_check_mysql, \
    admin_s3_bucket_clear
from tfl.ingestion import ingestion_module
from tfl.support.logger_module import get_logger

logger = get_logger(__name__)

def lambda_handler(event, context):

    event_values = event or {}
    # now = datetime.now().strftime("%Y-%m-%d-%H%M%S")
    logger.debug(f"event_values: {event_values}")

    run_mode = event_values.get("run_mode", None)

    test_mode_setup(event_values)

    function_map = {
        "health_sm" : health_sm,
        "health_s3" : health_s3,
        "health_mysql" : health_mysql,
        "health_hello" : health_hello,
        "admin_s3_clear" : admin_clear_s3_bucket,
    }

    function_map.get(run_mode, trigger_data_ingestion)(event)

    return {
        "statusCode": 200,
        "body": "Hello from Lambda!"
    }

def test_mode_setup(event_values):
    is_test_mode = event_values.get("is_test_mode", True)
    if is_test_mode:
        os.environ["IS_TEST_MODE"] = "true"

def trigger_data_ingestion(event):
    db_connection = get_connection()
    s3_path = S3Paths(refresh=True)
    s3_store = create_boto3_s3_store(bucket=s3_path.head_bucket(), region_name="eu-west-2")
    logger.debug(f"s3_store: {s3_store}, db_connection: {db_connection}")

    ingestion_module.start_data_ingestion(db_connection, s3_store)

def health_sm(event):
    logger.debug("SECRET M: Hello from Lambda!")
    health_check_secrets_manager()
    return {
        "statusCode": 200,
    }

def health_s3(event):
    logger.debug("S3: Hello from Lambda!")
    health_check_s3()
    return {
        "statusCode": 200,
    }

def health_mysql(event):
    logger.debug("MySQL: Hello from Lambda!")
    health_check_mysql()
    return {
        "statusCode": 200,
    }

def admin_clear_s3_bucket(event):
    logger.debug("Clear S3: About to clear bucket")
    admin_s3_bucket_clear(event)
    return {
        "statusCode": 200,
    }

def health_hello(event):
    logger.debug("Hello from Lambda!")
    return {
        "statusCode": 200,
    }
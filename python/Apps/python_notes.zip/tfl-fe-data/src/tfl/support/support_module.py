

def strtobool(val: str) -> bool:
    if val is None:
        return False
    return val.lower() in ("1", "true", "yes", "y", "on")


import logging
import os
from typing import Optional

def _parse_level(value: Optional[str], default: int = logging.INFO) -> int:
    if not value:
        return default
    v = value.strip()
    # Accept numeric (e.g., "20")
    if v.isdigit():
        return int(v)
    # Accept names (e.g., "info", "WARNING")
    level = logging.getLevelName(v.upper())
    return level if isinstance(level, int) else default

def get_logger(name: str) -> logging.Logger:
    """
    Return a library-safe logger for `name`.

    - Adds a NullHandler to avoid 'No handler found' warnings.
    - Does not add Stream/File handlers or formatters (leave to the application).
    - Respects LOG_LEVEL if present, otherwise leaves effective level to be resolved by parents.
    """
    logger = logging.getLogger(name)

    # Attach a NullHandler exactly once (library best practice).
    if not any(isinstance(h, logging.NullHandler) for h in logger.handlers):
        logger.addHandler(logging.NullHandler())

    # Optionally allow override via env while staying library-safe.
    env_level = _parse_level(os.getenv("LOG_LEVEL"), default=logging.NOTSET)
    if env_level != logging.NOTSET:
        logger.setLevel(env_level)

    return logger

from datetime import datetime
import json

from tfl.aws.s3.s3_store import S3Store
from tfl.support.logger_module import get_logger

logger = get_logger(__name__)

def build_message(name: str) -> str:
    cleaned = name.strip() or "World"
    return f"Hello, {cleaned}!"

def process_data(s3_input_json: str, s3_store: S3Store):

    write_input_file_if_missing(s3_store, s3_input_json)

    name = read_input_file(s3_store, s3_input_json)

    output_file = write_output_to_s3(s3_store, name)

    return {"statusCode": 200, "body": f"Wrote object s3://{output_file}"}

def write_input_file_if_missing(s3_store: S3Store, s3_input_json: str):
    # This function can be called at startup to ensure the input file exists
    # It can also be used in local testing to set up the environment
    if not s3_store.exists(s3_input_json):
        now = datetime.now().strftime("%Y-%m-%d-%H%M%S")

        key = "lambda-data-input.json"
        input_body = {
            "lambda": "data",
            "name": "james",
            "timestamp": now,
        }
        # convert to bytes for S3
        input_payload_bytes = json.dumps(input_body).encode("utf-8")
        s3_store.write_bytes(key, input_payload_bytes, content_type="application/json")

    return  # Input file already exists, no need to write

def read_input_file(s3_store: S3Store, s3_input_json: str) -> str:
    if s3_store.exists(s3_input_json):
        input_bytes = s3_store.read_bytes(s3_input_json)
        input_data = json.loads(input_bytes.decode("utf-8"))
        return input_data.get("name", "World")
    return "World"

def write_output_to_s3(s3_store: S3Store, name: str) -> str:
    now = datetime.now().strftime("%Y-%m-%d-%H%M%S")

    message = f"Hello {name} from Lambda!"
    body = {
        "message": message,
        "timestamp": now,
    }
    # Convert to bytes for S3
    payload_bytes = json.dumps(body).encode("utf-8")

    # The object key you want to write
    key = f"tfl-data-lambda/day-{now}/lambda-output/data-{now}.json"

    # Write to S3
    s3_store.write_bytes(key, payload_bytes, content_type="application/json")

    return key
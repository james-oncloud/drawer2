"""Core business logic for the Lambda sample."""

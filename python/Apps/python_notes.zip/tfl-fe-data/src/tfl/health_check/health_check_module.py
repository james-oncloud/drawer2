import json

from botocore.exceptions import ClientError

from tfl.aws.boto3_modul import S3InstanceBuilder
from tfl.aws.mysql.mysql_client import get_connection
from tfl.aws.s3.paths import S3Paths
from tfl.aws.s3.s3_store import create_boto3_s3_store, S3Store
from tfl.aws.secrets_manager import get_liftdb_secret
from tfl.ingestion.bss_lyft.ingest_model import TableReader
from tfl.support.logger_module import get_logger

logger = get_logger(__name__)

def read_input_file_from_s3() -> str:
    s3_store = create_boto3_s3_store(
        bucket="tfl-lambda-test-bucket-1234567890",
        region_name="eu-west-2",
        client=S3InstanceBuilder().build().s3_client
    )
    s3_input_json = "person.json"
    input_bytes = s3_store.read_bytes(s3_input_json)
    input_data = input_bytes.decode("utf-8")
    return input_data

def health_check_secrets_manager():
    logger.debug("running health_check_secrets_manager")
    try:
        logger.debug(f"About to get liftdb_secret")
        liftdb_secret = json.loads(get_liftdb_secret())
        logger.debug(f"SUCCESS: secret values: {liftdb_secret}") #toremove
        return liftdb_secret
    except ClientError as e:
        logger.error(f"SECRETS MANGER ERROR {e}")
        raise e

def health_check_s3():
        content = read_input_file_from_s3()
        logger.debug(f"SUCCESS: {content}")

def health_check_mysql():
    logger.debug("running health_check_mysql")
    rows = TableReader(("SubscriptionTypeDim", "GetSubscriptionTypeDim"), get_connection()).read()
    logger.debug(f"rows count: {len(rows)}")

def admin_s3_bucket_clear(event):
    event_values = event or {}

    s3_paths = S3Paths()
    bucket_prefix = event_values.get("bucket_prefix", s3_paths.head_bucket())

    s3_instance = S3InstanceBuilder().build()

    for bucket in s3_instance.s3_client.list_buckets()['Buckets']:
        bucket_name = bucket['Name']
        if bucket_name.startswith(bucket_prefix):
            _delete_bucket(s3_instance.s3_resource, s3_instance.s3_client, bucket_name)

    return {
            "statusCode": 200,
            "headers": {
                "Content-Type": "application/json"
            }
    }

# toremove
def _delete_bucket(s3_resource, s3_client, bucket_name):
    bucket = s3_resource.Bucket(bucket_name)
    logger.debug(f"\nDeleting bucket: {bucket_name}")

    # 1. Delete all object versions (for versioned buckets)
    try:
        bucket.object_versions.delete()
        logger.debug("Deleted object versions")
    except Exception as e:
        logger.error("No versioned objects or error:", e)

    # 2. Delete regular objects
    try:
        bucket.objects.all().delete()
        logger.debug("Deleted objects")
    except Exception as e:
        logger.error("No objects or error:", e)

    # 3. Delete the bucket itself
    s3_client.delete_bucket(Bucket=bucket_name)
    logger.debug("Bucket deleted")
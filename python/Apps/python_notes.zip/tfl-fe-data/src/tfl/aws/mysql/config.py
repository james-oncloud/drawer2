"""Configuration objects and env loading for MySQL."""

from dataclasses import dataclass
import os

@dataclass(frozen=True)
class MySQLConfig:
    host: str
    port: int
    user: str
    password: str
    database: str
    pool_name: str
    pool_size: int

    class MySQLConfigBuilder:
        """Builder for MySQLConfig with env defaults and fluent overrides."""

        def __init__(self):
            # Load defaults from environment
            self._host = os.getenv("MYSQL_HOST", "127.0.0.1")
            self._port = int(os.getenv("MYSQL_PORT", "3306"))
            self._user = os.getenv("MYSQL_USER", "root")
            self._password = os.getenv("MYSQL_PASSWORD", "rootpass")
            self._database = os.getenv("MYSQL_DATABASE", "usersdb")
            self._pool_name = os.getenv("MYSQL_POOL_NAME", "mysql_pool")
            self._pool_size = int(os.getenv("MYSQL_POOL_SIZE", "5"))

        # -------- Fluent setters --------

        def host(self, host: str) -> "MySQLConfigBuilder":
            self._host = host
            return self

        def port(self, port: int) -> "MySQLConfigBuilder":
            self._port = port
            return self

        def user(self, user: str) -> "MySQLConfigBuilder":
            self._user = user
            return self

        def password(self, password: str) -> "MySQLConfigBuilder":
            self._password = password
            return self

        def database(self, database: str) -> "MySQLConfigBuilder":
            self._database = database
            return self

        def pool_name(self, pool_name: str) -> "MySQLConfigBuilder":
            self._pool_name = pool_name
            return self

        def pool_size(self, pool_size: int) -> "MySQLConfigBuilder":
            self._pool_size = pool_size
            return self

        # -------- Build --------

        def build(self) -> MySQLConfig:
            """Create the immutable MySQLConfig."""
            return MySQLConfig(
                host=self._host,
                port=self._port,
                user=self._user,
                password=self._password,
                database=self._database,
                pool_name=self._pool_name,
                pool_size=self._pool_size,
            )
"""Custom exceptions for database abstraction."""


class DatabaseError(Exception):
    """Base exception for the data-access layer.

    Intention:
    - Give callers one predictable exception family to catch at boundaries.
    """


class DatabaseConnectionError(DatabaseError):
    """Raised when opening/closing or transaction control fails."""


class DatabaseQueryError(DatabaseError):
    """Raised when SQL execution or fetch operations fail."""


class InvalidIdentifierError(DatabaseError):
    """Raised when a dynamic table/column name fails safety validation."""
"""Concrete MySQL implementation for database abstraction interfaces."""

import json
from contextlib import contextmanager
from typing import Any, Iterable, Sequence

import mysql.connector
from mysql.connector.connection import MySQLConnection as NativeMySQLConnection
from mysql.connector.cursor import MySQLCursorDict
from mysql.connector.pooling import MySQLConnectionPool

from .abstractions import DatabaseClient, DatabaseConnection
from .config import MySQLConfig
from .exceptions import DatabaseConnectionError, DatabaseQueryError
from ..secrets_manager import get_liftdb_secret
from tfl.support.logger_module import get_logger

logger = get_logger(__name__)

class MySQLConnection(DatabaseConnection):
    """MySQL-specific connection provider backed by a connection pool.

    Intention:
    - Centralize low-level connection setup/teardown.
    - Reuse pooled connections for better throughput under load.
    """

    def __init__(self, config: MySQLConfig) -> None:
        """Build a reusable connection pool from application config."""
        self._config = config
        self._pool = MySQLConnectionPool(
            pool_name=config.pool_name,
            pool_size=config.pool_size,
            host=config.host,
            port=config.port,
            user=config.user,
            password=config.password,
            database=config.database,
        )
        self._conn: NativeMySQLConnection | None = None

    @property
    def is_connected(self) -> bool:
        """Report whether the currently checked-out pooled connection is alive."""
        return bool(self._conn and self._conn.is_connected())

    def connect(self) -> None:
        """Checkout a pooled connection if one is not already active."""
        if self.is_connected:
            return
        try:
            self._conn = self._pool.get_connection()
        except mysql.connector.Error as exc:
            raise DatabaseConnectionError(f"Unable to connect to MySQL: {exc}") from exc

    def disconnect(self) -> None:
        """Return the active pooled connection back to the pool."""
        if self._conn is None:
            return
        try:
            self._conn.close()
        except mysql.connector.Error as exc:
            raise DatabaseConnectionError(f"Unable to close MySQL connection: {exc}") from exc
        finally:
            self._conn = None

    def cursor(self) -> MySQLCursorDict:
        """Create a dict-based cursor so rows are accessed by column name."""
        if not self.is_connected:
            self.connect()
        if self._conn is None:
            raise DatabaseConnectionError("MySQL connection is not available.")
        return self._conn.cursor(dictionary=True)

    def commit(self) -> None:
        """Commit pending work on the current connection."""
        if self._conn is None:
            return
        try:
            self._conn.commit()
        except mysql.connector.Error as exc:
            raise DatabaseConnectionError(f"Commit failed: {exc}") from exc

    def rollback(self) -> None:
        """Rollback pending work on the current connection."""
        if self._conn is None:
            return
        try:
            self._conn.rollback()
        except mysql.connector.Error as exc:
            raise DatabaseConnectionError(f"Rollback failed: {exc}") from exc


class MySQLClient(DatabaseClient):
    """High-level MySQL client used by repositories and services.

    Intention:
    - Wrap cursor lifecycle in a consistent API.
    - Normalize connector exceptions into project-specific exceptions.
    """

    def __init__(self, connection: MySQLConnection) -> None:
        """Inject a connection provider to keep execution logic testable."""
        self._connection = connection

    def execute(self, query: str, params: Sequence[Any] | None = None) -> int:
        """Run one DML statement and commit automatically on success."""
        try:
            with self._connection.cursor() as cursor:
                cursor.execute(query, params)
                row_count = cursor.rowcount
            self._connection.commit()
            return row_count
        except mysql.connector.Error as exc:
            self._connection.rollback()
            raise DatabaseQueryError(f"Query execution failed: {exc}") from exc

    def executemany(self, query: str, params: Iterable[Sequence[Any]]) -> int:
        """Run one DML statement with many parameter sets in one call."""
        try:
            with self._connection.cursor() as cursor:
                cursor.executemany(query, params)
                row_count = cursor.rowcount
            self._connection.commit()
            return row_count
        except mysql.connector.Error as exc:
            self._connection.rollback()
            raise DatabaseQueryError(f"Bulk query execution failed: {exc}") from exc

    def fetch_one(self, query: str, params: Sequence[Any] | None = None) -> dict[str, Any] | None:
        """Run a query and return the first row only."""
        try:
            with self._connection.cursor() as cursor:
                cursor.execute(query, params)
                row = cursor.fetchone()
            return row
        except mysql.connector.Error as exc:
            raise DatabaseQueryError(f"Fetch one failed: {exc}") from exc

    def fetch_all(self, query: str, params: Sequence[Any] | None = None) -> list[dict[str, Any]]:
        """Run a query and return all rows."""
        try:
            with self._connection.cursor() as cursor:
                cursor.execute(query, params)
                rows = cursor.fetchall()
            return rows
        except mysql.connector.Error as exc:
            raise DatabaseQueryError(f"Fetch all failed: {exc}") from exc

    @contextmanager
    def transaction(self):
        """Execute multiple operations under one explicit transaction boundary."""
        self._connection.connect()
        try:
            yield self
            self._connection.commit()
        except Exception:
            # Roll back the whole unit of work if any statement fails.
            self._connection.rollback()
            raise

    def fetch_last_insert_id(self) -> int:
        """Read the last auto-increment value generated in this session."""
        row = self.fetch_one("SELECT LAST_INSERT_ID() AS id")
        if row is None:
            return 0
        return int(row["id"])

    def close(self) -> None:
        """Release any active pooled connection resource."""
        self._connection.disconnect()

def _get_liftdb_secret():
    try:
        logger.debug(f"about to get liftdb_secret")
        liftdb_secret = json.loads(get_liftdb_secret())
        logger.debug(f"SUCCESS secrets_manager: {liftdb_secret}")
        return liftdb_secret
    except Exception as e:
        logger.error(e)
    finally:
        logger.debug("timed-out so using hardcoded values")
        liftdb_secret = json.loads("{\"username\":\"dm_london_stg_akkodis\","
                                     "\"password\":\"zS2kdgU1SAcFrSzt2yBIOfuh\","
                                     "\"engine\":\"mysql\","
                                     "\"host\":\"datamart.uat-london.internal.lyftbikestesting.com\","
                                     "\"port\":\"3306\","
                                     "\"dbname\":\"london_staging_mining\","
                                     "\"ConnectionString\":\"Server=datamart.uat-london.internal.lyftbikestesting.com;Port=3306;Database=london_staging_mining;User Id=dm_london_stg_akkodis;Password=zS2kdgU1SAcFrSzt2yBIOfuh\"}")
    return liftdb_secret

def get_connection() -> MySQLConnection:
    """Factory function to create a MySQLConnection"""
    liftdb_secret = _get_liftdb_secret()
    logger.debug(f"using liftdb_secret: {liftdb_secret}")

    db_config = (MySQLConfig.MySQLConfigBuilder()
                 .user(liftdb_secret.get("username"))
                 .password(liftdb_secret.get("password"))
                 .host(liftdb_secret.get("host"))
                 .port(int(liftdb_secret.get("port", 3306)))
                 .database(liftdb_secret.get("dbname"))
                 .build())
    logger.debug(f"db_config: {db_config}")
    return MySQLConnection(db_config)

def get_mysql_client() -> MySQLClient:
    """Factory function to create a MySQLClient with a connection pool."""
    connection = get_connection()
    logger.debug(f"db_connection initialized: {connection}")
    return MySQLClient(connection)
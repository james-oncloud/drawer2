"""Reusable CRUD repository implementation."""

from __future__ import annotations

import re
from typing import Any

from .abstractions import DatabaseClient, Repository
from .exceptions import InvalidIdentifierError
from tfl.support.logger_module import get_logger

logger = get_logger(__name__)

IDENTIFIER_PATTERN = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")


def _validate_identifier(name: str) -> str:
    """Allow only safe SQL identifiers for dynamic table/column usage."""
    if not IDENTIFIER_PATTERN.fullmatch(name):
        raise InvalidIdentifierError(f"Invalid SQL identifier: {name!r}")
    return name


class BaseRepository(Repository):
    """Generic repository for one table using DatabaseClient primitives.

    Intention:
    - Provide reusable CRUD building blocks.
    - Keep dynamic SQL safe by validating identifiers up front.
    """

    def __init__(self, db: DatabaseClient, table_name: str, id_column: str = "id") -> None:
        """Bind repository to a table and its identifier column."""
        self._db = db
        self._table_name = _validate_identifier(table_name)
        self._id_column = _validate_identifier(id_column)

    def get_by_id(self, entity_id: Any) -> dict[str, Any] | None:
        """Fetch exactly one row by primary identifier."""
        query = (
            f"SELECT * FROM `{self._table_name}` "
            f"WHERE `{self._id_column}` = %s LIMIT 1"
        )
        return self._db.fetch_one(query, (entity_id,))

    def list(self, limit: int = 100, offset: int = 0) -> list[dict[str, Any]]:
        """Return a paginated list of rows."""
        query = f"SELECT * FROM `{self._table_name}` LIMIT %s OFFSET %s"
        return self._db.fetch_all(query, (limit, offset))

    def insert(self, data: dict[str, Any]) -> int:
        """Insert one row and return the generated identifier."""
        if not data:
            raise ValueError("Insert data cannot be empty.")
        columns = [_validate_identifier(column) for column in data.keys()]
        placeholders = ", ".join(["%s"] * len(columns))
        column_sql = ", ".join([f"`{column}`" for column in columns])
        query = f"INSERT INTO `{self._table_name}` ({column_sql}) VALUES ({placeholders})"
        self._db.execute(query, tuple(data[column] for column in columns))
        # return self._db.fetch_last_insert_id()
        return data[self._id_column]

    def update(self, entity_id: Any, data: dict[str, Any]) -> int:
        """Update one row by id and return affected row count."""
        if not data:
            raise ValueError("Update data cannot be empty.")
        columns = [_validate_identifier(column) for column in data.keys()]
        set_sql = ", ".join([f"`{column}` = %s" for column in columns])
        query = (
            f"UPDATE `{self._table_name}` SET {set_sql} "
            f"WHERE `{self._id_column}` = %s"
        )
        values = [data[column] for column in columns]
        values.append(entity_id)
        return self._db.execute(query, tuple(values))

    def delete(self, entity_id: Any) -> int:
        """Delete one row by id and return affected row count."""
        query = f"DELETE FROM `{self._table_name}` WHERE `{self._id_column}` = %s"
        return self._db.execute(query, (entity_id,))

    def find_by(self, **filters: Any) -> list[dict[str, Any]]:
        """Find rows by equality filters combined with AND."""
        if not filters:
            return self.list()
        columns = [_validate_identifier(column) for column in filters.keys()]
        where_sql = " AND ".join([f"`{column}` = %s" for column in columns])
        query = f"SELECT * FROM `{self._table_name}` WHERE {where_sql}"
        values = tuple(filters[column] for column in columns)
        return self._db.fetch_all(query, values)

    def count(self) -> int:
        """Return total row count for the table."""
        row = self._db.fetch_one(f"SELECT COUNT(*) AS total FROM `{self._table_name}`")
        if row is None:
            return 0
        return int(row["total"])
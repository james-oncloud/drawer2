"""Abstract interfaces for DB connection, client, and repository."""

from abc import ABC, abstractmethod
from contextlib import AbstractContextManager
from typing import Any, Iterable, Sequence


class DatabaseConnection(ABC):
    """Contract for raw connection lifecycle and cursor access.

    Intention:
    - Keep connection concerns isolated from query logic.
    - Allow swapping concrete providers (MySQL, SQLite, mocks in tests).
    """

    @property
    @abstractmethod
    def is_connected(self) -> bool:
        """Expose current connectivity state without forcing a new connection."""
        ...

    @abstractmethod
    def connect(self) -> None:
        """Open a connection if one is not already active."""
        ...

    @abstractmethod
    def disconnect(self) -> None:
        """Close and release any active connection resources."""
        ...

    @abstractmethod
    def cursor(self) -> Any:
        """Return a DB cursor used by higher-level clients to execute SQL."""
        ...

    @abstractmethod
    def commit(self) -> None:
        """Persist the current transaction."""
        ...

    @abstractmethod
    def rollback(self) -> None:
        """Revert the current transaction after an execution failure."""
        ...


class DatabaseClient(ABC):
    """Contract for executing SQL and controlling transactions.

    Intention:
    - Provide a small, backend-agnostic API for repositories/services.
    - Hide cursor management and backend-specific exceptions.
    """

    @abstractmethod
    def execute(self, query: str, params: Sequence[Any] | None = None) -> int:
        """Execute one write/update statement and return affected row count."""
        ...

    @abstractmethod
    def executemany(self, query: str, params: Iterable[Sequence[Any]]) -> int:
        """Execute one statement for multiple parameter sets."""
        ...

    @abstractmethod
    def fetch_one(self, query: str, params: Sequence[Any] | None = None) -> dict[str, Any] | None:
        """Fetch a single row as a mapping, or None when there is no row."""
        ...

    @abstractmethod
    def fetch_all(self, query: str, params: Sequence[Any] | None = None) -> list[dict[str, Any]]:
        """Fetch all matching rows as a list of mappings."""
        ...

    @abstractmethod
    def transaction(self) -> AbstractContextManager["DatabaseClient"]:
        """Return a context manager that wraps multiple calls in one transaction."""
        ...

    @abstractmethod
    def close(self) -> None:
        """Release any underlying resources held by the client."""
        ...


class Repository(ABC):
    """Contract for table-focused CRUD data access.

    Intention:
    - Keep SQL details localized in repository implementations.
    - Expose a stable domain-facing interface for callers.
    """

    @abstractmethod
    def get_by_id(self, entity_id: Any) -> dict[str, Any] | None:
        """Load one entity by its primary identifier."""
        ...

    @abstractmethod
    def list(self, limit: int = 100, offset: int = 0) -> list[dict[str, Any]]:
        """Page through entities in a deterministic order defined by implementation."""
        ...

    @abstractmethod
    def insert(self, data: dict[str, Any]) -> int:
        """Create one entity and return its generated identifier."""
        ...

    @abstractmethod
    def update(self, entity_id: Any, data: dict[str, Any]) -> int:
        """Update one entity and return affected row count."""
        ...

    @abstractmethod
    def delete(self, entity_id: Any) -> int:
        """Delete one entity and return affected row count."""
        ...

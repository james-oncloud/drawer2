


import boto3
import json
from botocore.exceptions import ClientError
from tfl.support.logger_module import get_logger

logger = get_logger(__name__)

def get_liftdb_secret():

    secret_name = "LiftDB"
    region_name = "eu-west-2"

    # Create a Secrets Manager client
    session = boto3.session.Session()
    client = session.client(
        service_name='secretsmanager',
        region_name=region_name
    )

    try:
        get_secret_value_response = client.get_secret_value(
            SecretId=secret_name
        )
    except ClientError as e:
        # For a list of exceptions thrown, see
        # https://docs.aws.amazon.com/secretsmanager/latest/apireference/API_GetSecretValue.html
        logger.error(e)
        return json.loads("{}") # return hardcoded values in this case

    secret = get_secret_value_response['SecretString']
    logger.debug(f"LeftDb secrets: {secret}") #toremove

    return secret
"""S3 storage interfaces and implementations.

This module is intentionally small and self-contained so it can be used in
test-driven development flows with mocks and botocore Stubber.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Protocol, cast, runtime_checkable

import boto3
from botocore.exceptions import ClientError
from tfl.support.logger_module import get_logger

logger = get_logger(__name__)

class S3StoreError(Exception):
    """Base exception raised by S3 store implementations."""


class S3ObjectNotFoundError(S3StoreError):
    """Raised when an S3 object cannot be found."""


@dataclass(frozen=True)
class S3Object:
    """Typed container for object location and payload."""

    bucket: str
    key: str
    data: bytes
    content_type: str | None = None
    metadata: dict[str, str] | None = None


@runtime_checkable
class S3Store(Protocol):
    """Behavioral contract for reading and writing objects."""

    def read_bytes(self, key: str) -> bytes:
        """Return object bytes for the given key."""

    def write_bytes(
        self,
        key: str,
        data: bytes,
        *,
        content_type: str | None = None,
        metadata: dict[str, str] | None = None,
    ) -> None:
        """Persist bytes at the given key."""

    def exists(self, key: str) -> bool:
        """Return True when the key exists in the bucket."""

    def delete(self, key: str) -> None:
        """Delete object if present."""


class Boto3S3Store(S3Store):
    """Production S3Store backed by boto3 S3 client."""

    def __init__(self, bucket: str, *, client: Any) -> None:
        if not bucket:
            raise ValueError("bucket must be a non-empty string")
        self._bucket = bucket
        self._client = client

    @property
    def bucket(self) -> str:
        return self._bucket

    def read_bytes(self, key: str) -> bytes:
        self._validate_key(key)
        try:
            response = self._client.get_object(Bucket=self._bucket, Key=key)
            return cast(bytes, response["Body"].read())
        except ClientError as error:
            if self._is_not_found(error):
                raise S3ObjectNotFoundError(f"s3://{self._bucket}/{key}") from error
            raise S3StoreError(f"failed reading s3://{self._bucket}/{key}") from error

    def write_bytes(
        self,
        key: str,
        data: bytes,
        *,
        content_type: str | None = None,
        metadata: dict[str, str] | None = None,
    ) -> None:
        self._validate_key(key)
        payload: dict[str, Any] = {"Bucket": self._bucket, "Key": key, "Body": data}
        if content_type is not None:
            payload["ContentType"] = content_type
        if metadata is not None:
            payload["Metadata"] = metadata
        try:
            self._client.put_object(**payload)
        except ClientError as error:
            raise S3StoreError(f"failed writing s3://{self._bucket}/{key}") from error

    def exists(self, key: str) -> bool:
        self._validate_key(key)
        try:
            self._client.head_object(Bucket=self._bucket, Key=key)
            return True
        except ClientError as error:
            if self._is_not_found(error):
                return False
            raise S3StoreError(f"failed checking s3://{self._bucket}/{key}") from error

    def delete(self, key: str) -> None:
        self._validate_key(key)
        try:
            self._client.delete_object(Bucket=self._bucket, Key=key)
        except ClientError as error:
            raise S3StoreError(f"failed deleting s3://{self._bucket}/{key}") from error

    @staticmethod
    def _validate_key(key: str) -> None:
        if not key:
            raise ValueError("key must be a non-empty string")

    @staticmethod
    def _is_not_found(error: ClientError) -> bool:
        code = error.response.get("Error", {}).get("Code")
        return code in {"NoSuchKey", "404", "NotFound"}



def s3_bucket_exists(bucket: str, s3_client) -> tuple[bool, str]:
    try:
        s3_client.head_bucket(Bucket=bucket)
        return True, "exists"
    except ClientError as e:
        code = int(e.response["ResponseMetadata"]["HTTPStatusCode"])
        if code == 404:
            return False, "does_not_exist"
        if code == 403:
            return True, "exists_but_access_denied"
        if code == 301:
            return False, "wrong_region"
        return False, f"error_{code}"

def create_boto3_s3_store(
    bucket: str,
    *,
    region_name: str | None = None,
    session: Any | None = None,
    client: Any | None = None
) -> Boto3S3Store:
    """Factory for Boto3S3Store with injectable session/client for testing.

    Use one of the following patterns:
    - Production: create_boto3_s3_store("my-bucket", region_name="eu-west-1")
    - Stubber tests: create_boto3_s3_store("my-bucket", client=stubbed_client)

    When ``create_bucket`` is True the factory will try to create the bucket
    when it does not already exist. If bucket creation fails for reasons like
    permission or ownership conflicts a ``S3StoreError`` is raised.
    """
    if client is not None and session is not None:
        raise ValueError("pass either client or session, not both")
    if client is None:
        active_session = session or boto3.session.Session()
        client = active_session.client("s3", region_name=region_name)
        if not s3_bucket_exists(bucket, client)[0]:
            client.create_bucket(Bucket=bucket, CreateBucketConfiguration={"LocationConstraint": region_name})

    return Boto3S3Store(bucket=bucket, client=client)

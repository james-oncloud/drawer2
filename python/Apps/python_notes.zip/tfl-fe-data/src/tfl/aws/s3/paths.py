import os
from datetime import datetime, timedelta
from tfl.support.support_module import strtobool

class S3Paths:
    yesterday = None
    def __init__(self, yesterday_in=None, refresh=False):

        date_pattern = "%Y-%m-%d"
        if bool(strtobool(os.getenv("IS_TEST_MODE", "0"))):
            date_pattern = "%Y-%m-%d-%H%M%S"

        if yesterday_in:
            S3Paths.yesterday = yesterday_in.strftime(date_pattern)
        else:
            if (not S3Paths.yesterday) or refresh:
                S3Paths.yesterday = (datetime.now() - timedelta(days=1)).strftime(date_pattern)

    def head_bucket(self) -> str:
        return "tfl-financial-engin-data-days"

    def day(self) -> str:
        return f"{S3Paths.yesterday}"

    def landing(self) -> str:
        return f"{self.day()}/landing"

    def accounts_json(self) -> str:
        return f"{self.landing()}/accounts.json"

    def billing_documents_json(self) -> str:
        return f"{self.landing()}/billingdocuments.json"

    def billing_lines_json(self) -> str:
        return f"{self.landing()}/billinglines.json"

    def payments_json(self) -> str:
        return f"{self.landing()}/payments.json"

    def rentals_json(self) -> str:
        return f"{self.landing()}/rentals.json"

    def subscriptions_json(self) -> str:
        return f"{self.landing()}/subscriptions.json"

    def validated(self) -> str:
        return f"{self.day()}/validated"

    def invalid(self) -> str:
        return f"{self.day()}/invalid"


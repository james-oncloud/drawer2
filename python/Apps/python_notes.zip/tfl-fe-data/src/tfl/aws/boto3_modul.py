
import boto3
from tfl.support.logger_module import get_logger

logger = get_logger(__name__)

class boto3_object:

    def __init__(self, session, s3_client, s3_resource):
        self.session = session
        self.s3_client = s3_client
        self.s3_resource = s3_resource

    def create_bucket(self, bucket_name, region_name):
        try:
            self.s3_client.head_bucket(Bucket=bucket_name)
        except Exception:
            self.s3_client.create_bucket(Bucket=bucket_name,
                                    CreateBucketConfiguration={'LocationConstraint': region_name})

class S3InstanceBuilder:
    local: bool

    def __init__(self):
        self.endpoint_url = "http://localhost:4566"
        self.region_name = "eu-west-2"
        self.aws_access_key_id = "test"
        self.aws_secret_access_key = "test"
        self.local = False
        # self.create_head_bucket = False
        # self.bucket_name = f"tfl-data-days-test-{datetime.now().strftime("%Y-%m-%d-%H%M%S")}"

    def with_endpoint_url(self, endpoint_url):
        self.endpoint_url = endpoint_url
        return self

    def with_region_name(self, region_name):
        self.region_name = region_name
        return self

    def with_aws_access_key_id(self, aws_access_key_id):
        self.aws_access_key_id = aws_access_key_id
        return self

    def with_aws_secret_access_key(self, aws_secret_access_key):
        self.aws_secret_access_key = aws_secret_access_key
        return self

    def is_local(self, local = True):
        self.local = local
        return self

    def build(self):
        if self.local:
            session = boto3.Session()
            s3_client = session.client(
                "s3",
                endpoint_url=self.endpoint_url,
                region_name=self.region_name,
                aws_access_key_id=self.aws_access_key_id,
                aws_secret_access_key=self.aws_secret_access_key
            )
            s3 = boto3.resource(
                "s3",
                endpoint_url=self.endpoint_url,
                region_name=self.region_name,
                aws_access_key_id=self.aws_access_key_id,
                aws_secret_access_key=self.aws_secret_access_key
            )
        else:
            session = boto3.Session()
            s3_client = session.client("s3")
            s3 = boto3.resource("s3")

        return boto3_object(session, s3_client, s3)
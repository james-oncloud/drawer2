from __future__ import annotations

from tfl import handler_data_ingestion
from tfl.handler import lambda_handler
from tfl.aws.boto3_modul import S3InstanceBuilder

def main():
    main_2()

def main_2():
    handler_data_ingestion.lambda_handler(None, None)

def main_1(argv: list[str] | None = None) -> int:

    s3_instance = (S3InstanceBuilder()
                   .is_local()
                   .build())

    event = {
        "local": "Local Tester",
        "s3_instance": s3_instance
    }

    lambda_handler(event, None)

    return 0

if __name__ == "__main__":
    raise SystemExit(main())

"""AWS Lambda sample package."""

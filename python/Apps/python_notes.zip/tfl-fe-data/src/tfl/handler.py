from __future__ import annotations

import json
from collections.abc import Mapping
from datetime import datetime
from typing import Any

from tfl.aws.boto3_modul import S3InstanceBuilder
from tfl.core.service import build_message, process_data
from tfl.aws.s3.s3_store import create_boto3_s3_store
from tfl.support.logger_module import get_logger

logger = get_logger(__name__)

def lambda_handler(event, context):

    event_values = event or {}

    now = datetime.now().strftime("%Y-%m-%d-%H%M%S")

    s3_instance = event_values.get("s3_instance", (S3InstanceBuilder().build()))
    bucket = event_values.get("bucket", f"tfl-data-days-{now}")
    s3_input_json = event_values.get("s3_input_json", f"lambda-data-input.json")
    region_name = event_values.get("region_name", "eu-west-2")

    s3_instance.create_bucket(bucket_name=bucket, region_name=region_name)

    return process_data(
        s3_input_json,
        create_boto3_s3_store(bucket, region_name=region_name, client=s3_instance.s3_client)
    )

def _delete_bucket(s3, s3_client, bucket_name):
    bucket = s3.Bucket(bucket_name)
    logger.debug(f"\nDeleting bucket: {bucket_name}")

    # 1. Delete all object versions (for versioned buckets)
    try:
        bucket.object_versions.delete()
        logger.debug("  - Deleted object versions")
    except Exception as e:
        logger.debug("  - No versioned objects or error:", e)

    # 2. Delete regular objects
    try:
        bucket.objects.all().delete()
        logger.debug("  - Deleted objects")
    except Exception as e:
        logger.debug("  - No objects or error:", e)

    # 3. Delete the bucket itself
    s3_client.delete_bucket(Bucket=bucket_name)
    logger.debug("  ✔ Bucket deleted")

def lambda_handler_clear(event, context):
    event_values = event or {}
    local = event_values.get("local", None)
    bucket_prefix = event_values.get("bucket_prefix", "tfl-data-days-")

    s3_instance = event_values.get("s3_instance", (S3InstanceBuilder().build()))

    for bucket in s3_instance.s3_client.list_buckets()['Buckets']:
        name = bucket['Name']
        if name.startswith(bucket_prefix):
            _delete_bucket(s3_instance.s3, s3_instance.s3_client, name)

    return {
            "statusCode": 200,
            "headers": {
                "Content-Type": "application/json"
            }
    }

def lambda_handler_hello(event: Mapping[str, Any] | None, context: Any) -> dict[str, Any]:
    del context  # context is intentionally unused for this sample.

    payload = event or {}
    name_raw = payload.get("name", "World")
    name = str(name_raw).strip() or "World"

    body = {"message": build_message(name)}
    return {
        "statusCode": 200,
        "headers": {"Content-Type": "application/json"},
        "body": json.dumps(body),
    }

from __future__ import annotations

from tfl.ingestion.domain.models import BusinessRecord
from tfl.ingestion.ports.processing import ProcessingStep


class ProcessingPipeline:
    def __init__(self, steps: list[ProcessingStep]) -> None:
        self._steps = steps

    def run(self, record: BusinessRecord) -> BusinessRecord:
        current = record
        for step in self._steps:
            current = step.process(current)
        return current

    @staticmethod
    def default():
        return ProcessingPipeline([])

from __future__ import annotations

from collections.abc import Callable

from tfl.ingestion.adapters.processing.enrich_counterparty_step import EnrichCounterpartyStep
from tfl.ingestion.adapters.processing.normalize_currency_step import NormalizeCurrencyStep
from tfl.ingestion.adapters.processing.risk_classification_step import RiskClassificationStep
from tfl.ingestion.ports.processing import ProcessingStep

StepBuilder = Callable[[], ProcessingStep]


class StepFactory:
    REGISTRY: dict[str, StepBuilder] = {
        "normalize_currency": NormalizeCurrencyStep,
        "enrich_counterparty": EnrichCounterpartyStep,
        "risk_classification": RiskClassificationStep,
    }

    @classmethod
    def build_steps(cls, enabled_steps: list[str]) -> list[ProcessingStep]:
        steps: list[ProcessingStep] = []
        for step_name in enabled_steps:
            builder = cls.REGISTRY.get(step_name)
            if builder is None:
                raise ValueError(f"Unknown processing step: {step_name}")
            steps.append(builder())
        return steps

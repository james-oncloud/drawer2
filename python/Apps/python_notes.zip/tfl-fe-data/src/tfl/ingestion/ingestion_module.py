
from tfl.aws.mysql.mysql_client import MySQLConnection
from tfl.aws.s3.s3_store import S3Store
from tfl.ingestion.bss_lyft.data_pull_module import BssLyftDbSageDataIngestion
from tfl.support.logger_module import get_logger

logger = get_logger(__name__)


def start_data_ingestion(db_connection: MySQLConnection, s3_store: S3Store):
    """
    This function is responsible for starting the data ingestion process.
    It can be scheduled to run at regular intervals to ensure that the data is up-to-date.
    """
    logger.debug(f"starting data ingestion process")

    BssLyftDbSageDataIngestion(db_connection, s3_store).start_bss_lyft_pulling_data()
"""Simple framework for processing tasks in parallel."""

from __future__ import annotations

from concurrent.futures import Future, ThreadPoolExecutor
from dataclasses import dataclass, field
from typing import Any, Callable, Iterable


@dataclass(frozen=True)
class Task:
    """Represents a unit of work to execute in parallel."""

    # The function to execute
    func: Callable[..., Any]
    # Positional arguments passed to the function
    args: tuple[Any, ...] = field(default_factory=tuple)
    # Keyword arguments passed to the function
    kwargs: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class TaskResult:
    """Captures either a successful value or an error from a task."""

    # The original position of the task in the input sequence
    task_index: int
    # The return value if the task succeeded, None if it failed
    value: Any | None = None
    # The exception if the task failed, None if it succeeded
    error: BaseException | None = None


class ParallelProcessor:
    """Runs a list of tasks concurrently using a thread pool."""

    def __init__(self, max_workers: int | None = None) -> None:
        # Validate that max_workers is positive if explicitly provided
        if max_workers is not None and max_workers < 1:
            raise ValueError("max_workers must be >= 1 when provided")
        # Store max_workers for thread pool initialization (None = system default)
        self._max_workers = max_workers

    def run_tasks(self, tasks: Iterable[Task]) -> list[TaskResult]:
        """
        Execute all tasks in parallel and return results in input order.

        Each task is submitted immediately to the underlying executor.
        """
        # Convert iterable to list to allow multiple iterations and get length
        task_list = list(tasks)
        # Handle empty input case
        if not task_list:
            return []

        # Map futures to their original task indices for result ordering
        future_to_index: dict[Future[Any], int] = {}
        # Pre-allocate results list with None placeholders to preserve order
        results: list[TaskResult | None] = [None] * len(task_list)

        # Create and manage thread pool executor context
        with ThreadPoolExecutor(max_workers=self._max_workers) as executor:
            # Submit all tasks immediately to the thread pool
            for index, task in enumerate(task_list):
                future = executor.submit(task.func, *task.args, **task.kwargs)
                future_to_index[future] = index

            # Collect results as futures complete, preserving original order
            for future, index in future_to_index.items():
                try:
                    # Retrieve the result value and store in correct position
                    value = future.result()
                    results[index] = TaskResult(task_index=index, value=value, error=None)
                except BaseException as exc:  # noqa: BLE001 - intentional capture
                    # Store the exception and mark as failed
                    results[index] = TaskResult(task_index=index, value=None, error=exc)

        # Filter out None placeholders and return ordered results
        return [result for result in results if result is not None]
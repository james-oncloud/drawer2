﻿-- External payments (Direct Debit, cheques, PayPal, etc.)
-- Used for reconciliation against: HSBC bank deposits only
-- These payments bypass card processors (no Submission/BL010/EPA files)

SELECT 
    -- Primary identifier
    id AS Id,
    
    -- Payment request tracking
    paymentRequest_id AS PaymentRequest_Id,
    payment_id AS Payment_Id,
    paymentAttempt_Id AS PaymentAttempt_Id,
    
    -- Financial data for reconciliation (stored in smallest currency unit)
    amount AS Amount,
    
    -- Customer account information
    bikeAccountNumber AS BikeAccountNumber,
    bikeAccountType_id AS BikeAccountType_Id,
    
    -- Payment gateway references (typically NULL for external payments)
    merchantTxId AS MerchantTxId,
    externalReferenceNumber AS ExternalReferenceNumber,
    transactionId AS TransactionId,
    authorizationNumber AS AuthorizationNumber,
    
    -- Payment classification
    paymentType_id AS PaymentType_Id,
    paymentResult_id AS PaymentResult_Id,
    paymentResultReason_id AS PaymentResultReason_Id,
    paymentBusinessContext_id AS PaymentBusinessContext_Id,
    paymentMode_id AS PaymentMode_Id,
    paymentSourceType_id AS PaymentSourceType_Id,
    
    -- Credit card details (NULL for Direct Debits)
    creditCardType_id AS CreditCardType_Id,
    creditCardId AS CreditCardId,
    cardBin AS CardBin,
    cardBinBrand AS CardBinBrand,
    cardBinCountry AS CardBinCountry,
    cardBinSubType AS CardBinSubType,
    cardBinType AS CardBinType,
    cardBinResult_id AS CardBinResult_Id,
    
    -- Timestamp data for reconciliation and reporting
    creationDateTime AS CreationDateTime,
    creationDate_id AS CreationDate_Id,
    creationTime_id AS CreationTime_Id,
    initializationDateTime AS InitializationDateTime,
    initializationDate_id AS InitializationDate_Id,
    initializationTime_id AS InitializationTime_Id,
    completionDateTime AS CompletionDateTime,
    completionDate_id AS CompletionDate_Id,
    completionTime_id AS CompletionTime_Id,
    processingDateTime AS ProcessingDateTime,
    processingDate_id AS ProcessingDate_Id,
    processingTime_id AS ProcessingTime_Id,
    
    -- Partner information
    partnerName AS PartnerName,
    
    -- Additional payment details
    userDefinedPaymentType AS UserDefinedPaymentType,
    reasonCode AS ReasonCode,
    authorizeNetAvsStatus AS AuthorizeNetAvsStatus
    
FROM BikePaymentFact
WHERE 
    completionDate_id = @dateId
    AND paymentMode_id = 4798412    -- External only (Direct Debit, cheques, PayPal)
    -- Note: paymentResult_id filtering now done in application layer using PaymentResultDim
ORDER BY completionDateTime ASC;

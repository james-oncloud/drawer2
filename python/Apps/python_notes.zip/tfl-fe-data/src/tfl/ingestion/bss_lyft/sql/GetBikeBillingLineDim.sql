-- BikeBillingLineTypeDim -- billing line type classification
-- Purpose: maps charge types to Schedule 14 nominal codes (Annex B)
SELECT id AS Id, localizedValue0 AS LocalizedValue0
FROM BikeBillingLineTypeDim;
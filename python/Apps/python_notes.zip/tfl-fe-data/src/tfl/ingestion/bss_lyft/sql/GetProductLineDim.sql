-- BikeProductLineDim -- bike product line lookup
-- Purpose: STANDARD vs EBIKE derivation for Schedule 14 composite key
-- 1=Flex, 2=Plus, 3=Classic, 4=Watson
SELECT id AS Id, localizedValue0 AS LocalizedValue0
FROM BikeProductLineDim;

-- BikeSubscriptionTypeDim dimension table query
-- Reference: BSS Data Mart Schema Section 9.45
-- Purpose: Subscription type classification (Daily, Weekly, Annual, etc.)
-- Usage: Determine subscription frequency for nominal code mapping

SELECT
    id AS Id,
    name_localizedValue0 AS Name,
    userType_localizedValue0 AS UserType,
    subscriptionUserType AS SubscriptionUserType,
    endAfterDelayMins AS EndAfterDelayMins,
    creationDateTimeMs AS CreationDateTimeMs,
    modificationDateTimeMs AS ModificationDateTimeMs,
    description_localizedValue0 AS Description,
    onePaymentPrice AS OnePaymentPrice
FROM BikeSubscriptionTypeDim
ORDER BY id;

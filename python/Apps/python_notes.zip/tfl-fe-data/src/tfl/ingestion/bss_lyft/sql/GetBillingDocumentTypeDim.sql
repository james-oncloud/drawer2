-- BillingDocumentTypeDim dimension table query
-- Reference: BSS Data Mart Schema Section 9.54
-- Purpose:   Billing document type classification
-- Values:    1=Invoice, 2=Credit note, 3=Payment, 4=Refund

SELECT
    id AS Id,
    localizedValue0 AS LocalizedValue0
FROM BillingDocumentTypeDim
ORDER BY id;

-- PaymentResultDim dimension table query
-- Reference: BSS Data Mart Schema Section 9.76
-- Purpose: Payment result status classification (Success, Failed, Pending, Cancelled, Declined)
-- Usage: Filter successful payments in reconciliation, map to status field in Daily Payments feed

SELECT
    id AS Id,
    localizedValue0 AS LocalizedValue0
FROM PaymentResultDim
ORDER BY id;

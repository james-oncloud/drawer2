-- BikeRentalBillingStatusDim -- rental billing status lookup
-- 0=Not billed, 1=Billed, 2=Lost bike billed, 3=Pending
SELECT id AS Id, localizedValue0 AS LocalizedValue0
FROM BikeRentalBillingStatusDim;

-- DateDim dimension table query
-- Reference: BSS Data Mart Schema Section 9.64
-- Purpose: Calendar date dimension for date-based filtering and reporting
-- Usage: Join with fact tables on date_id columns, derive financial periods

SELECT
    id AS Id,
    dayOfMonthValue AS DayOfMonth,
    dayOfWeekValue AS DayOfWeek,
    dayOfWeek_localizedValue0 AS DayOfWeekName,
    dayOfYearValue AS DayOfYear,
    dayOfYear_localizedValue0 AS DayOfYearName,
    month AS Month,
    month_localizedValue0 AS MonthName,
    year AS Year,
    weekOfYearValue AS WeekOfYear
FROM DateDim
ORDER BY id;

-- CreditCardTypeDim dimension table query
-- Reference: BSS Data Mart Schema Section 9.63
-- Purpose: Credit card brand classification (Visa, Mastercard, Amex, Discover)
-- Usage: Join with BikePaymentFact on creditCardType_id for cardType reporting

SELECT
    id AS Id,
    localizedValue0 AS LocalizedValue0
FROM CreditCardTypeDim
ORDER BY id;

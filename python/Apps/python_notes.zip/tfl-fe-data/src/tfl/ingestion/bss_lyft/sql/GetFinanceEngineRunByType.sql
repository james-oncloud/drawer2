-- get the latest run for a date filtered by run_type
-- Purpose: sage lambda needs the recon run specifically, not its own sage runs
SELECT id, run_date AS RunDate, run_type AS RunType,
       status AS Status, correlation_id AS CorrelationId,
       inputs_complete AS InputsComplete, failure_stage AS FailureStage,
       failure_message AS FailureMessage,
       started_at AS StartedAt, finished_at AS FinishedAt
FROM finance_engine_runs
WHERE run_date = @runDate
  AND run_type = @runType
ORDER BY started_at DESC
LIMIT 1;

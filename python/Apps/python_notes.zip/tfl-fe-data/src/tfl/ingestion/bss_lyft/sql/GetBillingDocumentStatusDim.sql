-- BillingDocumentStatusDim dimension table query
-- Reference: BSS Data Mart Schema Section 9.53
-- Purpose: Billing document status classification
-- Values: 0=Pending, 1=Open, 2=Closed, 3=Cancelled

SELECT
    id AS Id,
    localizedValue0 AS LocalizedValue0
FROM BillingDocumentStatusDim
ORDER BY id;

-- TimeDim dimension table query
-- Reference: BSS Data Mart Schema Section 9.88
-- Purpose: Convert time_id to time-of-day values for timestamp reconstruction
-- Usage: Join with fact tables on creationTime_id, processingTime_id, etc.

SELECT
    id AS Id,
    hourOfDayValue AS Hour,
    minuteOfHourValue AS Minute
FROM TimeDim
ORDER BY id;

-- BikeCorporateProgramDim -- corporate programme details
-- Purpose: subsidizedAmount > 0 --> CORPORATE_IK, otherwise --> CORPORATE
SELECT id AS Id, name_localizedValue0 AS Name, subsidizedAmount AS SubsidizedAmount,
       maxAmount AS MaxAmount, bikeCorporateAccount_id AS CorporateAccount_Id
FROM BikeCorporateProgramDim;

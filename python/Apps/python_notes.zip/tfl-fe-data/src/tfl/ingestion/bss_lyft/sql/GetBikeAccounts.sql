-- BikeAccountFact query for customer accounts
-- Reference: BSS Data Mart Schema Section 4.2
-- Purpose: Retrieve customer account data for reconciliation and reporting
-- Parameter: @dateId (BIGINT) - DateDim.id for filtering by creation date (optional)

SELECT
    a.id AS Id,

    -- Timestamps
    a.creationDateTime AS CreationDateTime,
    a.creationDate_id AS CreationDate_Id,
    a.creationTime_id AS CreationTime_Id,

    -- Account identification
    a.publicAccountNumber AS PublicAccountNumber,
    a.accountType_id AS AccountType_Id,
    a.accountStatus_id AS AccountStatus_Id,

    -- Account holder information
    a.accountHolderTitle AS AccountHolderTitle,
    a.accountHolderFirstName AS AccountHolderFirstName,
    a.accountHolderMiddleName AS AccountHolderMiddleName,
    a.accountHolderLastName AS AccountHolderLastName,
    a.accountHolderEmail AS AccountHolderEmail,
    a.accountHolderPhoneNumber1 AS AccountHolderPhoneNumber1,
    a.accountHolderPhoneNumber2 AS AccountHolderPhoneNumber2,
    a.accountHolderPhoneNumber3 AS AccountHolderPhoneNumber3,

    -- Billing address
    a.billingAddressCivicNumber AS BillingAddressCivicNumber,
    a.billingAddressStreet AS BillingAddressStreet,
    a.billingAddressCity AS BillingAddressCity,
    a.billingAddressProvince AS BillingAddressProvince,
    a.billingAddressCountry AS BillingAddressCountry,
    a.billingAddressPostalCode AS BillingAddressPostalCode,
    a.billingAddressApartment AS BillingAddressApartment,

    -- Suspension flags
    a.suspensionReasonCreditCardExpired AS SuspensionReasonCreditCardExpired,
    a.suspensionReasonFailedPayment AS SuspensionReasonFailedPayment,
    a.suspensionReasonManuallySuspended AS SuspensionReasonManuallySuspended,
    a.suspensionReasonCreditCardInvalid AS SuspensionReasonCreditCardInvalid,
    a.suspensionReasonPendingCashPayment AS SuspensionReasonPendingCashPayment,

    -- Communication preferences
    a.optInSmsNotifications AS OptInSmsNotifications

FROM BikeAccountFact a
WHERE
    (@dateId IS NULL OR a.creationDate_id = @dateId)
ORDER BY a.creationDateTime ASC;

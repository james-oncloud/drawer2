-- BillingDocumentFact query for invoice and document tracking
-- Reference: BSS Data Mart Schema Section 5.5
-- Purpose: Retrieve billing documents for reconciliation (invoices, credit notes, payments, refunds)
-- Parameter: @dateId (BIGINT) - DateDim.id for filtering by creation date

SELECT
    d.id AS Id,

    -- Account reference
    d.account_id AS Account_Id,

    -- Financial data
    d.amount AS Amount,
    d.balance AS Balance,
    d.accountRunningBalance AS AccountRunningBalance,

    -- Document status timestamps (milliseconds since Unix epoch)
    d.creationDateTime AS CreationDateTime,
    d.pendingDateTime AS PendingDateTime,
    d.openedDateTime AS OpenedDateTime,
    d.closedDateTime AS ClosedDateTime,
    d.cancelledDateTime AS CancelledDateTime,

    -- Date identifiers
    d.creationDate_id AS CreationDate_Id,
    d.creationTime_id AS CreationTime_Id,
    d.pendingDate_id AS PendingDate_Id,
    d.pendingTime_id AS PendingTime_Id,
    d.openedDate_id AS OpenedDate_Id,
    d.openedTime_id AS OpenedTime_Id,
    d.closedDate_id AS ClosedDate_Id,
    d.closedTime_id AS ClosedTime_Id,
    d.cancelledDate_id AS CancelledDate_Id,
    d.cancelledTime_id AS CancelledTime_Id,

    -- Classification
    d.documentType_id AS DocumentType_Id,
    d.documentStatus_id AS DocumentStatus_Id,
    d.documentBusinessType_id AS DocumentBusinessType_Id,

    -- Related records
    d.billingStatement_id AS BillingStatement_Id,

    -- Dimension lookups
    dt.localizedValue0 AS DocumentTypeName,
    ds.localizedValue0 AS DocumentStatusName

FROM BillingDocumentFact d
    LEFT JOIN BillingDocumentTypeDim dt ON d.documentType_id = dt.id
    LEFT JOIN BillingDocumentStatusDim ds ON d.documentStatus_id = ds.id
WHERE
    d.creationDate_id = @dateId
ORDER BY d.creationDateTime ASC;

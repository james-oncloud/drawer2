-- BikeBillingLineFact -- central billing table
-- Purpose: all charges, credits, and adjustments for reconciliation and Sage posting
-- Parameter: @dateId (BIGINT) -- DateDim.id for filtering by creation date
SELECT
    -- Primary identifier
    id AS Id,
    version AS Version,
    
    -- Account information
    account_id AS Account_Id,
    accountNumber AS AccountNumber,
    accountType_id AS AccountType_Id,
    memberNumber AS MemberNumber,
    
    -- Timestamp data
    creationDateTime AS CreationDateTime,
    creationDate_id AS CreationDate_Id,
    creationTime_id AS CreationTime_Id,
    
    -- Billing line classification
    billingLineType_id AS BillingLineType_Id,
    
    -- Status timestamps
    openDateTime AS OpenDateTime,
    openDate_id AS OpenDate_Id,
    openTime_id AS OpenTime_Id,
    closedDateTime AS ClosedDateTime,
    closedDate_id AS ClosedDate_Id,
    closedTime_id AS ClosedTime_Id,
    
    -- Financial data (stored in smallest currency unit)
    amount AS Amount,
    
    -- Document references
    document_id AS Document_Id,
    documentType_id AS DocumentType_Id,
    documentStatus_id AS DocumentStatus_Id,
    documentBusinessType_id AS DocumentBusinessType_Id,
    
    -- Address fields
    apartment AS Apartment,
    city AS City,
    civicNumber AS CivicNumber,
    country AS Country,
    postalCode AS PostalCode,
    province AS Province,
    street AS Street,
    
    -- Location data
    originStation_id AS OriginStation_Id,
    originDistrict_id AS OriginDistrict_Id,
    destinationStation_id AS DestinationStation_Id,
    destinationDistrict_id AS DestinationDistrict_Id,
    
    -- Subscription information
    subscriptionType_id AS SubscriptionType_Id,
    subscription_id AS Subscription_Id,
    discountCode_id AS DiscountCode_Id,
    
    -- Lyft processing flags
    adjustedByLyft AS AdjustedByLyft,
    handledByLyft AS HandledByLyft,
    
    -- Related records
    subscriptionInstalment_id AS SubscriptionInstalment_Id,
    rental_id AS Rental_Id,
    subscriptionBillingLine_id AS SubscriptionBillingLine_Id,
    bikeKeyAssociation_id AS BikeKeyAssociation_Id,
    bikeHelmetTransaction_id AS BikeHelmetTransaction_Id,
    promotion_id AS Promotion_Id,
    adjustedBillingLine_id AS AdjustedBillingLine_Id,
    correctedBillingLine_id AS CorrectedBillingLine_Id,
    user_id AS User_Id,
    
    -- Additional data
    note AS Note,
    
    -- Payment references for reconciliation
    paymentRequest_id AS PaymentRequest_Id,
    paymentType_id AS PaymentType_Id,
    paymentMode_id AS PaymentMode_Id,
    paymentCreditCardType_id AS PaymentCreditCardType_Id,
    paymentUserDefinedPaymentType AS PaymentUserDefinedPaymentType,
    paymentExternalReferenceNumber AS PaymentExternalReferenceNumber,
    paymentProcessingDateTime AS PaymentProcessingDateTime,
    paymentProcessingDate_id AS PaymentProcessingDate_Id,
    paymentProcessingTime_id AS PaymentProcessingTime_Id,
    paymentResult_id AS PaymentResult_Id,
    paymentResultReason_id AS PaymentResultReason_Id,
    
    -- Tax information
    taxRate_id AS TaxRate_Id,
    taxRegion_id AS TaxRegion_Id,
    
    -- Outstanding amounts
    outstandingAmount AS OutstandingAmount,
    outstandingDate AS OutstandingDate,
    outstandingDate_id AS OutstandingDate_Id,
    outstandingTime_id AS OutstandingTime_Id

FROM BikeBillingLineFact
WHERE 
    creationDate_id = @dateId
    AND amount IS NOT NULL
ORDER BY creationDateTime ASC;
-- DateDim identifier lookup
-- Reference: BSS Data Mart Schema Section 9.64
-- Purpose: Retrieve date_id for filtering fact tables by date
-- Parameter: @year (INT), @month (INT), @day (INT)

SELECT id
FROM DateDim
WHERE year = @year
    AND month = @month
    AND dayOfMonthValue = @day
LIMIT 1;

-- BillingTaxStrategyDim -- VAT application strategy
-- 1=not applied, 2=inclusive, 3=exclusive
SELECT id AS Id, localizedValue0 AS LocalizedValue0
FROM BillingTaxStrategyDim;

-- DiscountCodeFact -- discount code lookup
-- Purpose: company_id --> GDC detection for Schedule 14 composite key
SELECT id AS Id, company_id AS Company_Id, type_id AS Type_Id
FROM DiscountCodeFact;

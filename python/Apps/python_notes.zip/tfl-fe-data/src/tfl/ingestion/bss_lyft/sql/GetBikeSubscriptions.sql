-- BikeSubscriptionFact query for subscription data
-- Reference: BSS Data Mart Schema Section 4.4
-- Purpose: Retrieve subscription transactions for revenue reporting and Annex B breakdown
-- Parameter: @dateId (BIGINT) - DateDim.id for filtering by purchase date

SELECT
    s.id AS Id,

    -- Financial data
    s.cancelCreditedAmount AS CancelCreditedAmount,
    s.creditedAmount AS CreditedAmount,
    s.purchasePrice AS PurchasePrice,
    s.subsidizeAmount AS SubsidizeAmount,
    s.totalPaid AS TotalPaid,

    -- Timestamps (milliseconds since Unix epoch)
    s.cancellation AS CancellationDateTime,
    s.end AS EndDateTime,
    s.start AS StartDateTime,

    -- Date identifiers
    s.cancellationDate_id AS CancellationDate_Id,
    s.cancellationTime_id AS CancellationTime_Id,
    s.endDate_id AS EndDate_Id,
    s.endTime_id AS EndTime_Id,
    s.startDate_id AS StartDate_Id,
    s.startTime_id AS StartTime_Id,
    s.purchaseDate_id AS PurchaseDate_Id,
    s.purchaseTime_id AS PurchaseTime_Id,

    -- Member information (degenerate dimension)
    s.member_accountNumber AS MemberAccountNumber,
    s.member_memberNumber AS MemberNumber,
    s.member_birthday AS MemberBirthday,
    s.member_country AS MemberCountry,
    s.member_gender AS MemberGender,
    s.member_language AS MemberLanguage,
    s.member_postalCode AS MemberPostalCode,

    -- Subscription chain
    s.nextSubscriptionId AS NextSubscriptionId,
    s.previousSubscriptionId AS PreviousSubscriptionId,

    -- Classification
    s.subscriptionType_id AS SubscriptionType_Id,
    s.status_id AS Status_Id,
    s.paymentTerms_id AS PaymentTerms_Id,
    s.program_id AS Program_Id,

    -- Discount and promotion references
    s.discountCodeRedemptionNumber AS DiscountCodeRedemptionNumber,
    s.discountCodePartnerBatchDim_id AS DiscountCodePartnerBatch_Id,
    s.creditCardBinPromotion_id AS CreditCardBinPromotion_Id,
    s.unlockSubscriptionTypePromotion_id AS UnlockSubscriptionTypePromotion_Id,
    s.campaignCodePromotion_id AS CampaignCodePromotion_Id,

    -- Dimension lookups
    st.name_localizedValue0 AS SubscriptionTypeName,
    ss.localizedValue0 AS StatusName

FROM BikeSubscriptionFact s
    LEFT JOIN BikeSubscriptionTypeDim st ON s.subscriptionType_id = st.id
    LEFT JOIN BikeSubscriptionStatusDim ss ON s.status_id = ss.id
WHERE
    s.purchaseDate_id = @dateId
ORDER BY s.start ASC;

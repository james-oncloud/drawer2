import json
from typing import Tuple, Any

from importlib.resources import files
from tfl.aws.mysql.mysql_client import MySQLConnection, MySQLClient
from tfl.aws.s3 import paths
from tfl.aws.s3.s3_store import S3Store
from tfl.ingestion.bss_lyft.data_model import SubscriptionTypeDim, TaxRateDim, BikeCorporateProgramDim, BikeDim, \
    DiscountCodeFact, BillingBusinessDocumentTypeDim
from tfl.ingestion.domain.validation import ValidationResult, ValidationError
from tfl.ingestion.ports.mappers import RecordMapper
from tfl.ingestion.ports.readers import DbSourceReader
from tfl.ingestion.ports.validators import Validator
from tfl.ingestion.ports.writers import JsonWriter, InvalidRecordSink, T
from dataclasses import asdict
from tfl.support.logger_module import get_logger

logger = get_logger(__name__)

class TableReader(DbSourceReader):

    def __init__(self, table: Tuple[str, str], db_connection: MySQLConnection):
        self.table_name = table[0]
        self.sql_file = table[1]
        self.db_connection = db_connection
        self.sql_client = MySQLClient(self.db_connection)

    def read(self) -> list[dict[str, Any]]:
        # This is a placeholder implementation. In a real implementation, this method would connect to a database
        # and execute a query to retrieve the data from the specified table.
        logger.debug(f"Reading data from table: {self.table_name}")

        return self._load_table_rows(self._load_sql_statement(self.sql_file))

    def _load_table_rows(self, sql):
        return self.sql_client.fetch_all(sql)

    def _load_sql_statement(self, sql_file):
        return self._clean_sql_lines((files("tfl.ingestion.bss_lyft.sql") / f"{sql_file}.sql")
                         .read_text(encoding="utf-8")
                         .splitlines())

    @staticmethod
    def _clean_sql_lines(lines):
        cleaned = []
        for line in lines:
            # skip comment-only lines starting with "--"
            if line.__contains__("--") or line == "":
                continue
            cleaned.append(line)
        return "\n".join(cleaned)

class RecordInvalidSink(InvalidRecordSink):

    def __init__(self, table_name: str, s3_store: S3Store):
        self.table_name = table_name
        self.s3_store = s3_store
        self.records: list[tuple[dict[str, Any], list[dict[str, Any]]]] = []

    def write(self, *, source: str, raw_record: dict[str, Any], errors: list[ValidationError]) -> None:
        e = [asdict(error) for error in errors]
        self.records.append((raw_record, e))

    def flush(self) -> None:
        """Flush buffered data if writer supports batching."""
        valid_data_path = f"{paths.S3Paths().invalid()}/{self.table_name}.json"
        json_str = json.dumps(self.records)
        bytes_data = json.dumps(json_str).encode("utf-8")
        self.s3_store.write_bytes(key=valid_data_path, data=bytes_data, content_type="application/json")

class RecordValidSink(JsonWriter[SubscriptionTypeDim]):
    def __init__(self, table_name: str, s3_store: S3Store):
        self.table_name = table_name
        self.s3_store = s3_store
        self.records: list[SubscriptionTypeDim] = []

    def write(self, record: SubscriptionTypeDim) -> None:
        self.records.append(record)

    def flush(self) -> None:
        """Flush buffered data if writer supports batching."""
        valid_data_path = f"{paths.S3Paths().validated()}/{self.table_name}.json"

        serializable_records = [record.__dict__ for record in self.records]
        bytes_data = json.dumps(serializable_records).encode("utf-8")

        self.s3_store.write_bytes(key=valid_data_path, data=bytes_data, content_type="application/json")


""" Mappers """
class SubscriptionTypeDimMapper(RecordMapper[SubscriptionTypeDim]):
    def map(self, raw: dict[str, Any]) -> SubscriptionTypeDim:
        return SubscriptionTypeDim(raw)
class TaxRateDimMapper(RecordMapper[TaxRateDim]):
    def map(self, raw: dict[str, Any]) -> TaxRateDim:
        return TaxRateDim(raw)
class BikeCorporateProgramDimMapper(RecordMapper[BikeCorporateProgramDim]):
    def map(self, raw: dict[str, Any]) -> BikeCorporateProgramDim:
        return BikeCorporateProgramDim(raw)
class BikeDimMapper(RecordMapper[BikeDim]):
    def map(self, raw: dict[str, Any]) -> BikeDim:
        return BikeDim(raw)
class DiscountCodeFactMapper(RecordMapper[DiscountCodeFact]):
    def map(self, raw: dict[str, Any]) -> DiscountCodeFact:
        return DiscountCodeFact(raw)
class BillingBusinessDocumentTypeDimMapper(RecordMapper[BillingBusinessDocumentTypeDim]):
    def map(self, raw: dict[str, Any]) -> BillingBusinessDocumentTypeDim:
        return BillingBusinessDocumentTypeDim(raw)

""" Validators """
class SubscriptionTypeDimValidator(Validator[SubscriptionTypeDim]):
    def validate(self, record: SubscriptionTypeDim) -> ValidationResult:
        return ValidationResult()
class TaxRateDimValidator(Validator[TaxRateDim]):
    def validate(self, record: TaxRateDim) -> ValidationResult:
        return ValidationResult()
class BikeCorporateProgramDimValidator(Validator[BikeCorporateProgramDim]):
    def validate(self, record: BikeCorporateProgramDim) -> ValidationResult:
        return ValidationResult()
class BikeDimValidator(Validator[BikeDim]):
    def validate(self, record: BikeDim) -> ValidationResult:
        return ValidationResult()
class DiscountCodeFactValidator(Validator[DiscountCodeFact]):
    def validate(self, record: DiscountCodeFact) -> ValidationResult:
        return ValidationResult()
class BillingBusinessDocumentTypeDimValidator(Validator[BillingBusinessDocumentTypeDim]):
    def validate(self, record: BillingBusinessDocumentTypeDim) -> ValidationResult:
        return ValidationResult()
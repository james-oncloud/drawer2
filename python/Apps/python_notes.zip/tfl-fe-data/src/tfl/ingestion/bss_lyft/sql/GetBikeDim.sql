-- BikeDim -- bike lookup
-- Purpose: productLine_id --> STANDARD vs EBIKE for Schedule 14 composite key
SELECT id AS Id, productLine_id AS ProductLine_Id
FROM BikeDim;

-- BikeSubscriptionStatusDim dimension table query
-- Reference: BSS Data Mart Schema Section 9.44
-- Purpose: Subscription activation status classification
-- Values: 0=Active, 2=To activate, 3=Cancelled, 4=Pending, 5=Expired

SELECT
    id AS Id,
    localizedValue0 AS LocalizedValue0
FROM BikeSubscriptionStatusDim
ORDER BY id;

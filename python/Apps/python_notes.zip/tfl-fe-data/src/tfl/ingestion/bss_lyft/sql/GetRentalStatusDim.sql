-- BikeRentalStatusDim -- rental lifecycle status lookup
-- Purpose: detect overdue rentals (status 12) for LATE_RETURN charge type
SELECT id AS Id, localizedValue0 AS LocalizedValue0
FROM BikeRentalStatusDim;

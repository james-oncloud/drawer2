﻿-- BSS Lyft TaxRateDim Query
-- Reference: BSS_Back_Office_Data_Mart_Schema_Definition__1_.pdf Section 9.85
-- Purpose: Tax rate lookup (20% UK standard VAT, 5% reduced rate, 0% zero-rated)
-- Used for: vatRate field in Daily Invoices feed (Schedule 14 Annex A 6.2(M))

SELECT 
    id,
    code,
    rate,
    name_localizedValue0 AS Description
FROM TaxRateDim
ORDER BY id;

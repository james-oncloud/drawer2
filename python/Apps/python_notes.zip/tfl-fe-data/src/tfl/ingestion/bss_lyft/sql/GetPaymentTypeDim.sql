-- PaymentTypeDim -- payment vs refund classification
-- Purpose: distinguish payments from refunds in reconciliation
SELECT id AS Id, localizedValue0 AS LocalizedValue0
FROM PaymentTypeDim;
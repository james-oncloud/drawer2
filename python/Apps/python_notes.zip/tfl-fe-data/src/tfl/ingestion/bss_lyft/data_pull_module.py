
from tfl.aws.mysql.mysql_client import MySQLConnection
from tfl.aws.s3.s3_store import S3Store
from tfl.ingestion.config import sage_bss_table_list_modul
from tfl.ingestion.bss_lyft.ingest_model import TableReader, SubscriptionTypeDimMapper, SubscriptionTypeDimValidator, \
    RecordInvalidSink, RecordValidSink, TaxRateDimMapper, BikeCorporateProgramDimMapper, \
    BikeDimMapper, DiscountCodeFactMapper, BillingBusinessDocumentTypeDimMapper, TaxRateDimValidator, \
    BikeCorporateProgramDimValidator, BikeDimValidator, DiscountCodeFactValidator, \
    BillingBusinessDocumentTypeDimValidator
from tfl.ingestion.core.ingestion_service import SourceIngestionConfig, RecordIngestionService
from tfl.ingestion.core.pipeline import ProcessingPipeline
from tfl.support.logger_module import get_logger

logger = get_logger(__name__)

class BssLyftDbSageDataIngestion:

    def __init__(self, db_connection: MySQLConnection, s3_store: S3Store):
        self.db_connection = db_connection
        self.s3_client = s3_store
        self._init()

    def start_bss_lyft_pulling_data(self):

        logger.debug(f"pulling data from BSS Lyft source")
        cfg = sage_bss_table_list_modul.load()

        logger.debug(f"cfg.dimensions.len {len(cfg.dimensions)}")
        table_ingest_configs = tuple(
            (
                table.name,
                table.sql,
                self.ingest_config[table.name]
            )
            for table in cfg.dimensions
        )
        logger.debug(f"table count: {len(table_ingest_configs)}")

        table_configs_list = list(
            config[2]
            for config in table_ingest_configs
        )
        logger.debug(f"table ingestion count: {len(table_configs_list)}")

        RecordIngestionService(sources=table_configs_list).run()

    def _init(self):
        self.ingest_config = {
            "SubscriptionTypeDim": SourceIngestionConfig(
                TableReader(("SubscriptionTypeDim", "GetSubscriptionTypeDim"), self.db_connection),
                SubscriptionTypeDimMapper(),
                SubscriptionTypeDimValidator(),
                RecordInvalidSink("SubscriptionTypeDim", self.s3_client),
                ProcessingPipeline.default(),
                RecordValidSink("SubscriptionTypeDim", self.s3_client)
            ),
            "TaxRateDim": SourceIngestionConfig(
                TableReader(("TaxRateDim", "GetTaxRateDim"), self.db_connection),
                TaxRateDimMapper(),
                TaxRateDimValidator(),
                RecordInvalidSink("TaxRateDim", self.s3_client),
                ProcessingPipeline.default(),
                RecordValidSink("TaxRateDim", self.s3_client)
            ),
            "CorporateProgramDim": SourceIngestionConfig(
                TableReader(("CorporateProgramDim", "GetCorporateProgramDim"), self.db_connection),
                BikeCorporateProgramDimMapper(),
                BikeCorporateProgramDimValidator(),
                RecordInvalidSink("CorporateProgramDim", self.s3_client),
                ProcessingPipeline.default(),
                RecordValidSink("CorporateProgramDim", self.s3_client)
            ),
            "BikeDim": SourceIngestionConfig(
                TableReader(("BikeDim", "GetBikeDim"), self.db_connection),
                BikeDimMapper(),
                BikeDimValidator(),
                RecordInvalidSink("BikeDim", self.s3_client),
                ProcessingPipeline.default(),
                RecordValidSink("BikeDim", self.s3_client)
            ),
            "DiscountCodeFact": SourceIngestionConfig(
                TableReader(("DiscountCodeFact", "GetDiscountCodeFact"), self.db_connection),
                DiscountCodeFactMapper(),
                DiscountCodeFactValidator(),
                RecordInvalidSink("DiscountCodeFact", self.s3_client),
                ProcessingPipeline.default(),
                RecordValidSink("DiscountCodeFact", self.s3_client)
            ),
            "BusinessDocumentTypeDim": SourceIngestionConfig(
                TableReader(("BusinessDocumentTypeDim", "GetBusinessDocumentTypeDim"), self.db_connection),
                BillingBusinessDocumentTypeDimMapper(),
                BillingBusinessDocumentTypeDimValidator(),
                RecordInvalidSink("BusinessDocumentTypeDim", self.s3_client),
                ProcessingPipeline.default(),
                RecordValidSink("BusinessDocumentTypeDim", self.s3_client)
            ),

        }
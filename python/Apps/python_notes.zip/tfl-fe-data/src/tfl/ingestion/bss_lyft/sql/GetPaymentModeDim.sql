-- PaymentModeDim dimension table query
-- Reference: BSS Data Mart Schema Section 9.75
-- Purpose: Payment mode classification (card, cash, external)
-- Usage: Filter payments by mode, map to paymentMode field in Daily Payments feed

SELECT
    id AS Id,
    localizedValue0 AS LocalizedValue0
FROM PaymentModeDim
ORDER BY id;

-- BillingBusinessDocumentTypeDim -- business document classification
-- Purpose: filter non-posting document types in the Sage pipeline
SELECT id AS Id, localizedValue0 AS LocalizedValue0
FROM BillingBusinessDocumentTypeDim;

-- BikeAccountStatusDim dimension table query
-- Reference: BSS Data Mart Schema Section 9.1
-- Purpose: Account status classification
-- Values: 0=OK/Active, 1=Suspended, 4=Blocked, 5=Partial, 6=Closed

SELECT
    id AS Id,
    localizedValue0 AS LocalizedValue0
FROM BikeAccountStatusDim
ORDER BY id;

-- BikeRentalFact query for completed rentals
-- Reference: BSS Data Mart Schema Section 6.6
-- Purpose:   Retrieve rental transactions for reconciliation and reporting
-- Parameter: @dateId (BIGINT) - DateDim.id for filtering by end date

SELECT
    r.id AS Id,

    -- Customer information
    r.member_accountNumber AS CustomerId,
    r.member_memberNumber AS MemberNumber,

    -- Timing data (milliseconds since Unix epoch)
    r.startTimeMs AS StartTimeMs,
    r.endTimeMs AS EndTimeMs,
    r.closingDateMs AS ClosingDateMs,

    -- Date identifiers for reporting
    r.startDate_id AS StartDate_Id,
    r.endDate_id AS EndDate_Id,

    -- Location data
    r.startStation_id AS StartStationId,
    r.endStation_id AS EndStationId,
    r.startDock_id AS StartDockId,
    r.endDock_id AS EndDockId,

    -- Asset identifier
    r.bike_id AS BikeId,

    -- Duration calculations
    r.duration AS Duration,
    r.billableDuration AS BillableDuration,
    r.billableDurationMs AS BillableDurationMs,
    r.totalDurationMs AS TotalDurationMs,

    -- Distance tracking
    r.distanceInMeters AS DistanceInMeters,

    -- Financial data for reconciliation
    r.finalPrice AS FinalPrice,
    r.usageFee AS UsageFee,
    r.outsideServiceAreaFee AS OutsideServiceAreaFee,
    r.electricBikeSurchargeFee AS ElectricBikeSurchargeFee,

    -- Status identifiers and descriptions
    r.status_id AS StatusId,
    rsd.localizedValue0 AS Status,
    r.rentalBillingStatus_id AS RentalBillingStatusId,
    rbsd.localizedValue0 AS RentalBillingStatus,

    -- Subscription and rate information
    r.subscriptionId AS SubscriptionId,
    r.subscriptionType_id AS SubscriptionTypeId,
    r.rate_id AS RateId,
    r.program_id AS ProgramId,

    -- Time credit tracking
    r.timeCreditUsage AS TimeCreditUsage,

    -- Version control
    r.version AS Version

FROM BikeRentalFact r
    LEFT JOIN BikeRentalStatusDim rsd ON r.status_id = rsd.id
    LEFT JOIN BikeRentalBillingStatusDim rbsd ON r.rentalBillingStatus_id = rbsd.id
WHERE
    r.endDate_id = @dateId
    AND r.status_id IN (22, 23)
    AND r.rentalBillingStatus_id IN (2, 3)
    AND r.finalPrice IS NOT NULL
    AND r.finalPrice > 0
ORDER BY r.endTimeMs ASC;

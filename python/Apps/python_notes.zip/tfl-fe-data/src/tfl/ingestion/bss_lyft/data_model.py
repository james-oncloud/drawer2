from dataclasses import dataclass
from typing import Any

@dataclass
class SubscriptionTypeDim:
    def __init__(self, raw: dict[str, Any]):
        self.id = raw["Id"]
        self.name = raw["Name"]
        self.user_type = raw["UserType"]
        self.subscription_user_type = raw["SubscriptionUserType"]
        self.end_after_delay_mins = raw["EndAfterDelayMins"]
        self.creation_date_time_ms = raw["CreationDateTimeMs"]
        self.modification_date_time_ms = raw["ModificationDateTimeMs"]
        self.description = raw["Description"]
        self.one_payment_price = raw["OnePaymentPrice"]

@dataclass
class TaxRateDim:
    def __init__(self, raw: dict[str, Any]):
        self.id = raw["id"]
        self.code = raw["code"]
        self.rate = raw["rate"]
        self.description = raw["Description"]

@dataclass
class BikeCorporateProgramDim:
    def __init__(self, raw: dict[str, Any]):
        self.id = raw["Id"]
        self.name = raw["Name"]
        self.subsidized_amount = raw["SubsidizedAmount"]
        self.max_amount = raw["MaxAmount"]
        self.corporate_account_id = raw["CorporateAccount_Id"]

@dataclass
class BikeDim:
    def __init__(self, raw: dict[str, Any]):
        self.id = raw["Id"]
        self.product_line_id = raw["ProductLine_Id"]

@dataclass
class DiscountCodeFact:
    def __init__(self, raw: dict[str, Any]):
        self.id = raw["Id"]
        self.company_id = raw["Company_Id"]
        self.type_id = raw["Type_Id"]

@dataclass
class BillingBusinessDocumentTypeDim:
    def __init__(self, raw: dict[str, Any]):
        self.id = raw["Id"]
        self.localized_value_0 = raw["LocalizedValue0"]

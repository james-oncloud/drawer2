-- BikeAccountTypeDim -- customer account classification
-- Purpose: 1=Member, 2=Casual --> maps to MEMBER/NONMEMBER in Schedule 14
SELECT id AS Id, localizedValue0 AS LocalizedValue0
FROM BikeAccountTypeDim;
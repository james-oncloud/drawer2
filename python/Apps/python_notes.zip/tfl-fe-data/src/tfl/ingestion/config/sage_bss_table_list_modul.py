import json

from pydantic import BaseModel
from typing import List

from importlib.resources import files

class Dimension(BaseModel):
    name: str
    sql: str

class Config(BaseModel):
    dimensions: List[Dimension]

def load():
    # point to the package that contains the resource
    pkg = "tfl.ingestion.config"  # i.e., the package where BssTableList.json lives

    path = files(pkg) / "SageBssTableList.json"
    text = path.read_text(encoding="utf-8")

    json_obj = json.loads(text)
    cfg = Config(**json_obj)

    return cfg

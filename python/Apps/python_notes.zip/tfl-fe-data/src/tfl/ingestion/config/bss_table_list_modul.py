import json

from pydantic import BaseModel
from typing import List

from importlib.resources import files


class Dimension(BaseModel):
    name: str
    sql: str

class Fact(BaseModel):
    name: str
    sql: str

class Settings(BaseModel):
    parallelBatchSize: int
    sqlFolder: str

class Config(BaseModel):
    dimensions: List[Dimension]
    facts: List[Fact]
    settings: Settings


def load():
    # point to the package that contains the resource
    pkg = "tfl.config"  # i.e., the package where BssTableList.json lives

    path = files(pkg) / "BssTableList.json"
    text = path.read_text(encoding="utf-8")

    json_obj = json.loads(text)
    cfg = Config(**json_obj)

    return cfg

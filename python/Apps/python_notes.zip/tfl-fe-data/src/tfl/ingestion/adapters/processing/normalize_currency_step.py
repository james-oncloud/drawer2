from __future__ import annotations

from dataclasses import replace

from tfl.ingestion.domain.models import BusinessRecord
from tfl.ingestion.ports.processing import ProcessingStep


class NormalizeCurrencyStep(ProcessingStep):
    def process(self, record: BusinessRecord) -> BusinessRecord:
        return replace(record, currency=record.currency.upper())

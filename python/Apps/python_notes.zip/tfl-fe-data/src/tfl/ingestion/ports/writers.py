from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any, TypeVar, Generic

from tfl.ingestion.domain.validation import ValidationError

T = TypeVar("T")

class Writer(ABC, Generic[T]):
    @abstractmethod
    def write(self, record: T) -> None:
        """Write a valid record to a sink."""

    def flush(self) -> None:
        """Flush buffered data if writer supports batching."""


class JsonWriter(Writer[T], ABC):
    """Port for writers that serialize output as JSON/JSONL."""


class InvalidRecordSink(ABC):
    @abstractmethod
    def write(
        self,
        *,
        source: str,
        raw_record: dict[str, Any],
        errors: list[ValidationError],
    ) -> None:
        """Persist invalid records with structured context."""

    def flush(self) -> None:
        """Flush buffered invalid output."""

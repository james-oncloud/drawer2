from __future__ import annotations

from abc import ABC, abstractmethod
from typing import TypeVar, Generic

from tfl.ingestion.domain.validation import ValidationResult

T = TypeVar("T")

class Validator(ABC, Generic[T]):
    @abstractmethod
    def validate(self, record: T) -> ValidationResult:
        """Run domain validation and return a structured result."""

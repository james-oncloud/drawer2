from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any, Generic, TypeVar

from tfl.ingestion.domain.models import BusinessRecord

T = TypeVar("T")

class RecordMapper(ABC, Generic[T]):
    @abstractmethod
    def map(self, raw: dict[str, Any]) -> T:
        """Map a raw record into the internal domain model."""


class BusinessRecordMapper(RecordMapper[BusinessRecord]):
    def map(self, raw: dict[str, Any]) -> BusinessRecord:
        return BusinessRecord(id=str(raw["id"]), name=str(raw["name"]))


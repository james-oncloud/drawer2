# AWS Lambda Python Sample

Modern Python 3 AWS Lambda project using a `src/` layout, `pyproject.toml`, tests, linting, typing, and CI.

## Project layout

```text
AWSLambda/
  pyproject.toml
  README.md
  LICENSE
  .gitignore
  src/
    aws_lambda_sample/
      __init__.py
      __main__.py
      cli.py
      handler.py
      core/
        __init__.py
        service.py
      py.typed
  tests/
    test_handler.py
    test_service.py
  scripts/
    dev.sh
  .github/workflows/
    ci.yml
```

## Quick start

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -U pip
python -m pip install -e ".[dev]"
```

## Package and Deploy

```bash
# create zip file for deployment
./.venv/Scripts/python ./scripts/build_zip.py
```
Should create `tfl_fe_data_lambda_deployment_<time_stamp>.zip` in the project root.
Deploy to AWS Lambda.

## Run locally

Call as a module:

```bash
python -m tfl --name James
```

Or via installed console script:

```bash
aws-lambda-sample --name James
```

## Lambda handler

Use the function:

```text
tfl.handler.lambda_handler
```

Sample event:

```json
{
  "name": "James"
}
```

Sample response:

```json
{
  "statusCode": 200,
  "headers": {
    "Content-Type": "application/json"
  },
  "body": "{\"message\":\"Hello, James!\"}"
}
```

## Quality checks

```bash
pytest -q
ruff check .
ruff format . --check
mypy src
```

## Build artifacts

```bash
python -m build
```

Outputs:
- `dist/*.whl`
- `dist/*.tar.gz`

## IAM Policy for S3 Access
```bash
{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Effect": "Allow",
            "Action": [
                "s3:CreateBucket",
                "s3:GetBucketLocation",
                "s3:PutObject",
                "s3:AbortMultipartUpload",
                "s3:GetObject",
                "s3:ListBucket",
                "s3:DeleteBucket",
                "s3:DeleteObject",
                "s3:DeleteObjectVersion",
                "s3:ListBucketVersions",
                "s3:ListAllMyBuckets"
            ],
            "Resource": [
                "arn:aws:s3:::*",
                "arn:aws:s3:::*/*"
            ]
        }
    ]
}
```
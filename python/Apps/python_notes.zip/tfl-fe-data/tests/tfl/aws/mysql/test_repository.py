import pytest

from tfl.aws.mysql.exceptions import InvalidIdentifierError
from tfl.aws.mysql.repository import BaseRepository, _validate_identifier

class FakeClient:
    def __init__(self) -> None:
        self.fetch_one_result = None
        self.fetch_all_result = []
        self.last_insert_id = 1
        self.execute_calls = []
        self.fetch_one_calls = []
        self.fetch_all_calls = []

    def execute(self, query, params=None):
        self.execute_calls.append((query, params))
        return 1

    def fetch_one(self, query, params=None):
        self.fetch_one_calls.append((query, params))
        return self.fetch_one_result

    def fetch_all(self, query, params=None):
        self.fetch_all_calls.append((query, params))
        return self.fetch_all_result

    def fetch_last_insert_id(self):
        return self.last_insert_id


def test_validate_identifier_valid():
    assert _validate_identifier("users") == "users"
    assert _validate_identifier("user_1") == "user_1"


@pytest.mark.parametrize("name", ["users;DROP TABLE users;", "user-name", "1users", ""])
def test_validate_identifier_invalid(name):
    with pytest.raises(InvalidIdentifierError):
        _validate_identifier(name)


def test_get_by_id_builds_expected_query():
    fake = FakeClient()
    fake.fetch_one_result = {"id": 2, "name": "Alice"}
    repo = BaseRepository(fake, "users")

    row = repo.get_by_id(2)

    assert row == {"id": 2, "name": "Alice"}
    assert fake.fetch_one_calls == [
        ("SELECT * FROM `users` WHERE `id` = %s LIMIT 1", (2,))
    ]


def test_list_builds_expected_query():
    fake = FakeClient()
    fake.fetch_all_result = [{"id": 1}, {"id": 2}]
    repo = BaseRepository(fake, "users")

    rows = repo.list(limit=2, offset=3)

    assert len(rows) == 2
    assert fake.fetch_all_calls == [
        ("SELECT * FROM `users` LIMIT %s OFFSET %s", (2, 3))
    ]


def test_insert_executes_and_returns_last_insert_id():
    fake = FakeClient()
    fake.last_insert_id = 99
    repo = BaseRepository(fake, "users")

    inserted_id = repo.insert({"id": fake.last_insert_id, "name": "Alice", "email": "a@example.com"})

    assert inserted_id == 99
    assert fake.execute_calls == [
        (
            "INSERT INTO `users` (`id`, `name`, `email`) VALUES (%s, %s, %s)",
            (fake.last_insert_id, "Alice", "a@example.com"),
        )
    ]


def test_insert_rejects_empty_data():
    fake = FakeClient()
    repo = BaseRepository(fake, "users")

    with pytest.raises(ValueError, match="Insert data cannot be empty"):
        repo.insert({})


def test_update_executes_expected_query():
    fake = FakeClient()
    repo = BaseRepository(fake, "users")

    updated = repo.update(7, {"name": "Bob"})

    assert updated == 1
    assert fake.execute_calls == [
        ("UPDATE `users` SET `name` = %s WHERE `id` = %s", ("Bob", 7))
    ]


def test_update_rejects_empty_data():
    fake = FakeClient()
    repo = BaseRepository(fake, "users")

    with pytest.raises(ValueError, match="Update data cannot be empty"):
        repo.update(1, {})


def test_delete_executes_expected_query():
    fake = FakeClient()
    repo = BaseRepository(fake, "users")

    deleted = repo.delete(11)

    assert deleted == 1
    assert fake.execute_calls == [("DELETE FROM `users` WHERE `id` = %s", (11,))]


def test_find_by_with_filters_builds_expected_query():
    fake = FakeClient()
    fake.fetch_all_result = [{"id": 4, "name": "Alice"}]
    repo = BaseRepository(fake, "users")

    rows = repo.find_by(name="Alice", email="a@example.com")

    assert rows == [{"id": 4, "name": "Alice"}]
    assert fake.fetch_all_calls == [
        (
            "SELECT * FROM `users` WHERE `name` = %s AND `email` = %s",
            ("Alice", "a@example.com"),
        )
    ]


def test_find_by_without_filters_delegates_to_list():
    fake = FakeClient()
    fake.fetch_all_result = [{"id": 1}]
    repo = BaseRepository(fake, "users")

    rows = repo.find_by()

    assert rows == [{"id": 1}]
    assert fake.fetch_all_calls == [("SELECT * FROM `users` LIMIT %s OFFSET %s", (100, 0))]


def test_count_returns_int():
    fake = FakeClient()
    fake.fetch_one_result = {"total": 27}
    repo = BaseRepository(fake, "users")

    count = repo.count()

    assert count == 27
    assert fake.fetch_one_calls == [("SELECT COUNT(*) AS total FROM `users`", None)]
# pyright: reportMissingImports=false
from typing import Any

import pytest
import mysql.connector

from tfl.aws.mysql.abstractions import DatabaseConnection
from tfl.aws.mysql.exceptions import DatabaseQueryError
from tfl.aws.mysql.mysql_client import MySQLClient


class FakeCursor:
    def __init__(self) -> None:
        self.rowcount = 1
        self.fetchone_result: dict[str, Any] | None = {"id": 1}
        self.fetchall_result: list[dict[str, Any]] = [{"id": 1}, {"id": 2}]
        self.execute_raises = False
        self.executemany_raises = False
        self.execute_calls = []
        self.executemany_calls = []

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        return False

    def execute(self, query, params=None):
        self.execute_calls.append((query, params))
        if self.execute_raises:
            raise mysql.connector.Error("execute failed")

    def executemany(self, query, params):
        params_list = list(params)
        self.executemany_calls.append((query, params_list))
        if self.executemany_raises:
            raise mysql.connector.Error("executemany failed")

    def fetchone(self):
        return self.fetchone_result

    def fetchall(self):
        return self.fetchall_result


class FakeConnection(DatabaseConnection):
    def __init__(self) -> None:
        self.cursor_obj = FakeCursor()
        self.commit_calls = 0
        self.rollback_calls = 0
        self.connect_calls = 0
        self.disconnect_calls = 0
        self._connected = False

    @property
    def is_connected(self) -> bool:
        return self._connected

    def cursor(self):
        return self.cursor_obj

    def commit(self):
        self.commit_calls += 1

    def rollback(self):
        self.rollback_calls += 1

    def connect(self):
        self.connect_calls += 1
        self._connected = True

    def disconnect(self):
        self.disconnect_calls += 1
        self._connected = False


def test_execute_success_commits_and_returns_rowcount():
    conn = FakeConnection()
    client = MySQLClient(conn)

    result = client.execute("UPDATE users SET name=%s WHERE id=%s", ("Alice", 1))

    assert result == 1
    assert conn.commit_calls == 1
    assert conn.rollback_calls == 0
    assert conn.cursor_obj.execute_calls == [
        ("UPDATE users SET name=%s WHERE id=%s", ("Alice", 1))
    ]


def test_execute_failure_rolls_back_and_raises_database_query_error():
    conn = FakeConnection()
    conn.cursor_obj.execute_raises = True
    client = MySQLClient(conn)

    with pytest.raises(DatabaseQueryError, match="Query execution failed"):
        client.execute("UPDATE users SET name=%s WHERE id=%s", ("Alice", 1))

    assert conn.commit_calls == 0
    assert conn.rollback_calls == 1


def test_executemany_success_commits_and_returns_rowcount():
    conn = FakeConnection()
    conn.cursor_obj.rowcount = 3
    client = MySQLClient(conn)
    params = [(1, "A"), (2, "B"), (3, "C")]

    result = client.executemany("INSERT INTO t(id, name) VALUES(%s, %s)", params)

    assert result == 3
    assert conn.commit_calls == 1
    assert conn.rollback_calls == 0
    assert conn.cursor_obj.executemany_calls == [
        ("INSERT INTO t(id, name) VALUES(%s, %s)", params)
    ]


def test_executemany_failure_rolls_back_and_raises_database_query_error():
    conn = FakeConnection()
    conn.cursor_obj.executemany_raises = True
    client = MySQLClient(conn)

    with pytest.raises(DatabaseQueryError, match="Bulk query execution failed"):
        client.executemany("INSERT INTO t(id) VALUES(%s)", [(1,), (2,)])

    assert conn.commit_calls == 0
    assert conn.rollback_calls == 1


def test_fetch_one_returns_row():
    conn = FakeConnection()
    conn.cursor_obj.fetchone_result = {"id": 42, "name": "Alice"}
    client = MySQLClient(conn)

    row = client.fetch_one("SELECT * FROM users WHERE id=%s", (42,))

    assert row == {"id": 42, "name": "Alice"}
    assert conn.cursor_obj.execute_calls == [("SELECT * FROM users WHERE id=%s", (42,))]


def test_fetch_all_returns_rows():
    conn = FakeConnection()
    conn.cursor_obj.fetchall_result = [{"id": 1}, {"id": 2}]
    client = MySQLClient(conn)

    rows = client.fetch_all("SELECT * FROM users")

    assert rows == [{"id": 1}, {"id": 2}]
    assert conn.cursor_obj.execute_calls == [("SELECT * FROM users", None)]


def test_fetch_methods_wrap_connector_errors():
    conn = FakeConnection()
    conn.cursor_obj.execute_raises = True
    client = MySQLClient(conn)

    with pytest.raises(DatabaseQueryError, match="Fetch one failed"):
        client.fetch_one("SELECT 1")

    with pytest.raises(DatabaseQueryError, match="Fetch all failed"):
        client.fetch_all("SELECT 1")


def test_transaction_commits_on_success():
    conn = FakeConnection()
    client = MySQLClient(conn)

    with client.transaction() as tx_client:
        assert tx_client is client

    assert conn.connect_calls == 1
    assert conn.commit_calls == 1
    assert conn.rollback_calls == 0


def test_transaction_rolls_back_on_error():
    conn = FakeConnection()
    client = MySQLClient(conn)

    with pytest.raises(ValueError, match="boom"):
        with client.transaction():
            raise ValueError("boom")

    assert conn.connect_calls == 1
    assert conn.commit_calls == 0
    assert conn.rollback_calls == 1


def test_fetch_last_insert_id_reads_and_converts_id():
    conn = FakeConnection()
    conn.cursor_obj.fetchone_result = {"id": "7"}
    client = MySQLClient(conn)

    last_id = client.fetch_last_insert_id()

    assert last_id == 7
    assert conn.cursor_obj.execute_calls == [("SELECT LAST_INSERT_ID() AS id", None)]


def test_fetch_last_insert_id_returns_zero_when_row_missing():
    conn = FakeConnection()
    conn.cursor_obj.fetchone_result = None
    client = MySQLClient(conn)

    assert client.fetch_last_insert_id() == 0


def test_close_disconnects_connection():
    conn = FakeConnection()
    client = MySQLClient(conn)

    client.close()

    assert conn.disconnect_calls == 1
# pyright: reportMissingImports=false
from unittest.mock import Mock

import pytest
import mysql.connector

from tfl.aws.mysql.config import MySQLConfig
from tfl.aws.mysql.exceptions import DatabaseConnectionError
from tfl.aws.mysql.mysql_client import MySQLConnection


@pytest.fixture
def config():
    return MySQLConfig(
        host="127.0.0.1",
        port=3306,
        user="root",
        password="rootpass",
        database="employees",
        pool_name="test_pool",
        pool_size=2,
    )


@pytest.fixture
def fake_native_connection():
    conn = Mock()
    conn.is_connected.return_value = True
    conn.cursor.return_value = Mock()
    return conn


def test_connect_gets_connection_from_pool(monkeypatch, config, fake_native_connection):
    fake_pool = Mock()
    fake_pool.get_connection.return_value = fake_native_connection
    monkeypatch.setattr("tfl.aws.mysql.mysql_client.MySQLConnectionPool", lambda **kwargs: fake_pool)

    connection = MySQLConnection(config)
    connection.connect()

    assert connection.is_connected is True
    fake_pool.get_connection.assert_called_once()


def test_connect_is_noop_when_already_connected(monkeypatch, config, fake_native_connection):
    fake_pool = Mock()
    fake_pool.get_connection.return_value = fake_native_connection
    monkeypatch.setattr("tfl.aws.mysql.mysql_client.MySQLConnectionPool", lambda **kwargs: fake_pool)

    connection = MySQLConnection(config)
    connection.connect()
    connection.connect()

    fake_pool.get_connection.assert_called_once()


def test_connect_wraps_connector_error(monkeypatch, config):
    fake_pool = Mock()
    fake_pool.get_connection.side_effect = mysql.connector.Error("cannot connect")
    monkeypatch.setattr("tfl.aws.mysql.mysql_client.MySQLConnectionPool", lambda **kwargs: fake_pool)
    connection = MySQLConnection(config)

    with pytest.raises(DatabaseConnectionError, match="Unable to connect to MySQL"):
        connection.connect()


def test_disconnect_closes_active_connection(monkeypatch, config, fake_native_connection):
    fake_pool = Mock()
    fake_pool.get_connection.return_value = fake_native_connection
    monkeypatch.setattr("tfl.aws.mysql.mysql_client.MySQLConnectionPool", lambda **kwargs: fake_pool)
    connection = MySQLConnection(config)
    connection.connect()

    connection.disconnect()

    fake_native_connection.close.assert_called_once()
    assert connection.is_connected is False


def test_disconnect_wraps_connector_error(monkeypatch, config, fake_native_connection):
    fake_native_connection.close.side_effect = mysql.connector.Error("close failed")
    fake_pool = Mock()
    fake_pool.get_connection.return_value = fake_native_connection
    monkeypatch.setattr("tfl.aws.mysql.mysql_client.MySQLConnectionPool", lambda **kwargs: fake_pool)
    connection = MySQLConnection(config)
    connection.connect()

    with pytest.raises(DatabaseConnectionError, match="Unable to close MySQL connection"):
        connection.disconnect()

    assert connection.is_connected is False


def test_cursor_auto_connects_and_returns_dict_cursor(monkeypatch, config, fake_native_connection):
    fake_dict_cursor = Mock()
    fake_native_connection.cursor.return_value = fake_dict_cursor
    fake_pool = Mock()
    fake_pool.get_connection.return_value = fake_native_connection
    monkeypatch.setattr("tfl.aws.mysql.mysql_client.MySQLConnectionPool", lambda **kwargs: fake_pool)

    connection = MySQLConnection(config)
    cursor = connection.cursor()

    assert cursor is fake_dict_cursor
    fake_native_connection.cursor.assert_called_once_with(dictionary=True)


def test_commit_calls_native_commit(monkeypatch, config, fake_native_connection):
    fake_pool = Mock()
    fake_pool.get_connection.return_value = fake_native_connection
    monkeypatch.setattr("tfl.aws.mysql.mysql_client.MySQLConnectionPool", lambda **kwargs: fake_pool)
    connection = MySQLConnection(config)
    connection.connect()

    connection.commit()

    fake_native_connection.commit.assert_called_once()


def test_commit_wraps_connector_error(monkeypatch, config, fake_native_connection):
    fake_native_connection.commit.side_effect = mysql.connector.Error("commit failed")
    fake_pool = Mock()
    fake_pool.get_connection.return_value = fake_native_connection
    monkeypatch.setattr("tfl.aws.mysql.mysql_client.MySQLConnectionPool", lambda **kwargs: fake_pool)
    connection = MySQLConnection(config)
    connection.connect()

    with pytest.raises(DatabaseConnectionError, match="Commit failed"):
        connection.commit()


def test_rollback_calls_native_rollback(monkeypatch, config, fake_native_connection):
    fake_pool = Mock()
    fake_pool.get_connection.return_value = fake_native_connection
    monkeypatch.setattr("tfl.aws.mysql.mysql_client.MySQLConnectionPool", lambda **kwargs: fake_pool)
    connection = MySQLConnection(config)
    connection.connect()

    connection.rollback()

    fake_native_connection.rollback.assert_called_once()


def test_rollback_wraps_connector_error(monkeypatch, config, fake_native_connection):
    fake_native_connection.rollback.side_effect = mysql.connector.Error("rollback failed")
    fake_pool = Mock()
    fake_pool.get_connection.return_value = fake_native_connection
    monkeypatch.setattr("tfl.aws.mysql.mysql_client.MySQLConnectionPool", lambda **kwargs: fake_pool)
    connection = MySQLConnection(config)
    connection.connect()

    with pytest.raises(DatabaseConnectionError, match="Rollback failed"):
        connection.rollback()
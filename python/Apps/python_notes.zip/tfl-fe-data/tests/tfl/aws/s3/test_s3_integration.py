from __future__ import annotations

import json
import os
from contextlib import contextmanager

import boto3
import pytest
from botocore.exceptions import BotoCoreError, ClientError

from tfl.aws.boto3_modul import S3InstanceBuilder
from tfl.aws.s3.s3_store import create_boto3_s3_store

pytest.importorskip(
    "testcontainers",
    reason="Install test dependencies with: python3 -m pip install -e '.[test]'",
)
from testcontainers.core.container import DockerContainer
from testcontainers.core.waiting_utils import wait_for_logs

from tfl.aws.s3.s3_store import Boto3S3Store

@contextmanager
def _resolve_localstack_endpoint():
    """Yield endpoint URL from env var or from a Testcontainers LocalStack."""
    existing_endpoint = os.getenv("LOCALSTACK_ENDPOINT_URL", None) #"http://localhost:4566"
    if existing_endpoint:
        yield existing_endpoint
        return

    testcontainers = pytest.importorskip(
        "testcontainers",
        reason=(
            "Install test dependencies with: python3 -m pip install -e '.[test]' "
            "or set LOCALSTACK_ENDPOINT_URL to reuse an existing LocalStack."
        ),
    )
    _ = testcontainers  # Satisfies linters for importorskip side effect.

    with (
        DockerContainer("localstack/localstack:3")
        .with_env("SERVICES", "s3")
        .with_env("AWS_DEFAULT_REGION", "eu-west-2")
        .with_exposed_ports(4566)
    ) as localstack:
        wait_for_logs(localstack, "Ready.")
        host = localstack.get_container_host_ip()
        port = localstack.get_exposed_port(4566)
        yield f"http://{host}:{port}"


def _build_s3_client(endpoint_url: str):
    return boto3.client(
        "s3",
        endpoint_url=endpoint_url,
        region_name="eu-west-2",
        aws_access_key_id="test",
        aws_secret_access_key="test",
    )

@pytest.mark.integration
class TestS3IntegrationWithLocalStack:
    region_name = "eu-west-2"

    bucket_prefix = "integration-bucket"
    import uuid
    from datetime import datetime

    bucket_name = (
        f"{bucket_prefix}-{uuid.uuid4().hex[:8]}-{datetime.now().strftime('%Y-%m-%d-%H%M%S')}"
    )

    key = "data-files/data.json"
    payload = {"name": "james"}
    json_bytes = json.dumps(payload).encode("utf-8")

    def setup_method(self) -> None:
        self._endpoint_ctx = _resolve_localstack_endpoint()
        self.endpoint_url = self._endpoint_ctx.__enter__()
        self.client = _build_s3_client(self.endpoint_url)
        self._remove_existing_integration_buckets()
        self.client.create_bucket(
            Bucket=self.bucket_name,
            CreateBucketConfiguration={"LocationConstraint": self.region_name},
        )
        self.store = Boto3S3Store(bucket=self.bucket_name, client=self.client)

    def teardown_method(self) -> None:
        try:
            response = self.client.list_objects_v2(Bucket=self.bucket_name)
            for obj in response.get("Contents", []):
                self.client.delete_object(Bucket=self.bucket_name, Key=obj["Key"])
            self.client.delete_bucket(Bucket=self.bucket_name)
        except (ClientError, BotoCoreError):
            # Best-effort cleanup for already removed resources.
            pass
        finally:
            self._endpoint_ctx.__exit__(None, None, None)

    def _remove_existing_integration_buckets(self) -> None:
        response = self.client.list_buckets()
        for bucket in response.get("Buckets", []):
            bucket_name = bucket.get("Name", "")
            if bucket_name.startswith(self.bucket_prefix):
                self._delete_bucket_and_contents(bucket_name)

    def _delete_bucket_and_contents(self, bucket_name: str) -> None:
        continuation_token = None
        while True:
            params = {"Bucket": bucket_name}
            if continuation_token is not None:
                params["ContinuationToken"] = continuation_token
            response = self.client.list_objects_v2(**params)
            for obj in response.get("Contents", []):
                self.client.delete_object(Bucket=bucket_name, Key=obj["Key"])
            if not response.get("IsTruncated"):
                break
            continuation_token = response.get("NextContinuationToken")
        self.client.delete_bucket(Bucket=bucket_name)

    def test_s3_read_write_round_trip_with_testcontainers(self) -> None:

        # context manager
        with _resolve_localstack_endpoint() as endpoint_url:
            print(endpoint_url)

            client = (S3InstanceBuilder()
                      .with_endpoint_url(endpoint_url)
                      .with_region_name(self.region_name)
                      .is_local()
                      .build())

            client.create_bucket(bucket_name=self.bucket_name, region_name=self.region_name)

            try:
                store = create_boto3_s3_store(
                    bucket=self.bucket_name, region_name=self.region_name, client=client.s3_client
                )

                store.write_bytes(
                    self.key,
                    self.json_bytes,
                    content_type="text/plain",
                    metadata={"source": "integration"},
                )

                assert store.exists(self.key) is True
                assert store.read_bytes(self.key) == self.json_bytes

                # store.delete(self.key)
                # assert store.exists(self.key) is False
            except (ClientError, BotoCoreError) as error:
                pytest.fail(f"LocalStack S3 integration failed: {error}")

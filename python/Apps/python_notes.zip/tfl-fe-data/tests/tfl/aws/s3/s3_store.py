from __future__ import annotations

from tfl.aws.s3.s3_store import S3Store, S3Object, S3ObjectNotFoundError

class _FakeClient:
    def __init__(self, storage: dict[str, S3Object]):
        # storage maps key -> S3Object for a single bucket
        self._storage = storage

    def list_objects_v2(self, Bucket: str, **kwargs):
        contents = []
        for key in self._storage.keys():
            contents.append({"Key": key})
        return {"Contents": contents} if contents else {}

    def delete_object(self, Bucket: str, Key: str):
        self._storage.pop(Key, None)
        return {"ResponseMetadata": {"HTTPStatusCode": 204}}

    def delete_bucket(self, Bucket: str):
        self._storage.clear()
        return {"ResponseMetadata": {"HTTPStatusCode": 204}}

    def list_buckets(self):
        # Only a single bucket is modelled in this test helper; return a dummy name
        return {"Buckets": [{"Name": Bucket}] if (Bucket := "integration-bucket") else []}


class _DummyEndpointCtx:
    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        return False


class InMemoryS3Store(S3Store):
    """In-memory S3Store for test fixtures and local development."""

    def __init__(self, bucket: str) -> None:
        if not bucket:
            raise ValueError("bucket must be a non-empty string")
        self._bucket = bucket
        self._objects: dict[str, S3Object] = {}

        # Provide a fake client and endpoint context for test teardown expectations.
        self.client = _FakeClient(self._objects)
        self._endpoint_ctx = _DummyEndpointCtx()

        # Try to inject these onto the calling test instance (if any) so the
        # test's teardown can refer to `self.client` and `self._endpoint_ctx`.
        try:
            import inspect

            frame = inspect.currentframe()
            if frame is not None and frame.f_back is not None:
                caller_locals = frame.f_back.f_locals
                test_self = caller_locals.get("self")
                if test_self is not None:
                    if not hasattr(test_self, "client"):
                        setattr(test_self, "client", self.client)
                    if not hasattr(test_self, "_endpoint_ctx"):
                        setattr(test_self, "_endpoint_ctx", self._endpoint_ctx)
        except Exception:
            # best-effort; don't fail construction
            pass

    @property
    def bucket(self) -> str:
        return self._bucket

    def read_bytes(self, key: str) -> bytes:
        self._validate_key(key)
        obj = self._objects.get(key)
        if obj is None:
            raise S3ObjectNotFoundError(f"s3://{self._bucket}/{key}")
        return obj.data

    def write_bytes(
        self,
        key: str,
        data: bytes,
        *,
        content_type: str | None = None,
        metadata: dict[str, str] | None = None,
    ) -> None:
        self._validate_key(key)
        self._objects[key] = S3Object(
            bucket=self._bucket,
            key=key,
            data=data,
            content_type=content_type,
            metadata=dict(metadata or {}),
        )

    def exists(self, key: str) -> bool:
        self._validate_key(key)
        return key in self._objects

    def delete(self, key: str) -> None:
        self._validate_key(key)
        self._objects.pop(key, None)

    @staticmethod
    def _validate_key(key: str) -> None:
        if not key:
            raise ValueError("key must be a non-empty string")

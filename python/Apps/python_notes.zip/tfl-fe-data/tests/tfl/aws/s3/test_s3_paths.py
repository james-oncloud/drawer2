"""Unit tests for s3_paths class."""
from operator import eq

from datetime import datetime, timedelta
from unittest.mock import patch

from tfl.aws.s3.paths import S3Paths

def custom_datetime(datetime_str):
    """Helper function to return a fixed custom date for testing."""
    return datetime.strptime(datetime_str, "%Y-%m-%d")

class TestS3PathsBasicPaths:
    """Test basic path generation in s3_paths."""

    def test_head_bucket_returns_correct_base_path(self):
        """Test that head_bucket returns the correct base path."""
        assert S3Paths().head_bucket() == "tfl-financial-engin-data-days"

    def test_head_bucket_returns_string(self):
        """Test that head_bucket returns a string."""
        result = S3Paths().head_bucket()
        assert isinstance(result, str)

    def test_day_returns_string(self):
        """Test that day returns a string."""
        result = S3Paths().day()
        assert isinstance(result, str)

    def test_landing_returns_string(self):
        """Test that landing returns a string."""
        result = S3Paths().landing()
        assert isinstance(result, str)


class TestS3PathsDateHandling:
    """Test date handling in s3_paths."""

    def test_day_with_default_date(self):
        """Test that day() uses current date when no date is provided."""
        yesterday = (datetime.now() - timedelta(days=1)).strftime("%Y-%m-%d")
        result = S3Paths().day()
        expected = f"{yesterday}"
        assert result == expected

    def test_day_with_custom_date(self):
        """Test that day() uses provided date when passed as argument."""
        custom_date = "2026-01-15"
        yesterday = custom_datetime(custom_date)
        result = S3Paths(yesterday).day()
        expected = f"{custom_date}"
        assert result == expected

    def test_day_with_different_custom_dates(self):
        """Test day() with various custom dates."""
        test_dates = [
            "2025-12-25",
            "2026-03-05",
            "2024-01-01",
            "2099-12-31"
        ]
        for test_date in test_dates:
            yesterday = custom_datetime(test_date)
            result = S3Paths(yesterday).day()
            assert test_date in result
            assert result.startswith(f"{test_date}")

    @patch('tfl.aws.s3.paths.datetime')
    def test_day_uses_mocked_current_date(self, mock_datetime):
        """Test that day() uses current datetime when no date is provided."""
        yesterday = custom_datetime("2026-03-05")
        result = S3Paths(yesterday).day()
        assert "2026-03-05" in result


class TestS3PathsHierarchy:
    """Test path hierarchy and structure."""

    def test_landing_includes_day_path(self):
        """Test that landing path includes the day path."""
        day_path = S3Paths().day()
        landing_path = S3Paths().landing()
        assert landing_path.startswith(day_path)
        assert landing_path.endswith("/landing")

    def test_landing_path_structure(self):
        """Test that landing path has correct structure."""
        result = S3Paths().landing()
        # Should be: {date}/landing
        assert result.count('/') >= 1
        assert "landing" in result

    def test_accounts_json_includes_landing_path(self):
        """Test that accounts_json path includes landing path."""
        landing_path = S3Paths().landing()
        accounts_path = S3Paths().accounts_json()
        assert accounts_path.startswith(landing_path)
        assert accounts_path.endswith("accounts.json")

    def test_billing_documents_json_includes_landing_path(self):
        """Test that billing_documents_json path includes landing path."""
        landing_path = S3Paths().landing()
        billing_docs_path = S3Paths().billing_documents_json()
        assert billing_docs_path.startswith(landing_path)
        assert billing_docs_path.endswith("billingdocuments.json")

    def test_billing_lines_json_includes_landing_path(self):
        """Test that billing_lines_json path includes landing path."""
        landing_path = S3Paths().landing()
        billing_lines_path = S3Paths().billing_lines_json()
        assert billing_lines_path.startswith(landing_path)
        assert billing_lines_path.endswith("billinglines.json")

    def test_payments_json_includes_landing_path(self):
        """Test that payments_json path includes landing path."""
        landing_path = S3Paths().landing()
        payments_path = S3Paths().payments_json()
        assert payments_path.startswith(landing_path)
        assert payments_path.endswith("payments.json")

    def test_rentals_json_includes_landing_path(self):
        """Test that rentals_json path includes landing path."""
        landing_path = S3Paths().landing()
        rentals_path = S3Paths().rentals_json()
        assert rentals_path.startswith(landing_path)
        assert rentals_path.endswith("rentals.json")

    def test_subscriptions_json_includes_landing_path(self):
        """Test that subscriptions_json path includes landing path."""
        landing_path = S3Paths().landing()
        subscriptions_path = S3Paths().subscriptions_json()
        assert subscriptions_path.startswith(landing_path)
        assert subscriptions_path.endswith("subscriptions.json")


class TestS3PathsJsonFiles:
    """Test JSON file paths."""

    def test_all_json_files_end_with_json_extension(self):
        """Test that all JSON file paths end with .json."""
        json_files = [
            S3Paths().accounts_json(),
            S3Paths().billing_documents_json(),
            S3Paths().billing_lines_json(),
            S3Paths().payments_json(),
            S3Paths().rentals_json(),
            S3Paths().subscriptions_json(),
        ]
        for json_file in json_files:
            assert json_file.endswith(".json"), f"{json_file} does not end with .json"

    def test_accounts_json_path(self):
        """Test accounts.json path."""
        result = S3Paths().accounts_json()
        assert result.endswith("/accounts.json")
        assert "/landing/" in result

    def test_billing_documents_json_path(self):
        """Test billingdocuments.json path."""
        result = S3Paths().billing_documents_json()
        assert result.endswith("/billingdocuments.json")
        assert "/landing/" in result

    def test_billing_lines_json_path(self):
        """Test billinglines.json path."""
        result = S3Paths().billing_lines_json()
        assert result.endswith("/billinglines.json")
        assert "/landing/" in result

    def test_payments_json_path(self):
        """Test payments.json path."""
        result = S3Paths().payments_json()
        assert result.endswith("/payments.json")
        assert "/landing/" in result

    def test_rentals_json_path(self):
        """Test rentals.json path."""
        result = S3Paths().rentals_json()
        assert result.endswith("/rentals.json")
        assert "/landing/" in result

    def test_subscriptions_json_path(self):
        """Test subscriptions.json path."""
        result = S3Paths().subscriptions_json()
        assert result.endswith("/subscriptions.json")
        assert "/landing/" in result


class TestS3PathsConsistency:
    """Test consistency of path generation."""

    def test_multiple_calls_return_consistent_results(self):
        """Test that multiple calls to the same method return consistent results with same date."""
        custom_date = "2026-01-15"
        p = S3Paths(custom_datetime(custom_date))
        result1 = p.day()
        result2 = p.day()
        assert result1 == result2

    def test_all_paths_contain_head_bucket_prefix(self):
        """Test that all paths contain the head_bucket prefix."""
        p = S3Paths()
        head = p.head_bucket()
        paths = [
            p.day(),
            p.landing(),
            p.accounts_json(),
            p.billing_documents_json(),
            p.billing_lines_json(),
            p.payments_json(),
            p.rentals_json(),
            p.subscriptions_json(),
        ]
        for path in paths:
            assert not path.startswith(head), f"{path} does not start with {head}"

    def test_paths_do_not_contain_double_slashes(self):
        """Test that paths do not contain double slashes (except at start)."""
        p = S3Paths()
        paths = [
            p.head_bucket(),
            p.day(),
            p.landing(),
            p.accounts_json(),
            p.billing_documents_json(),
            p.billing_lines_json(),
            p.payments_json(),
            p.rentals_json(),
            p.subscriptions_json(),
        ]
        for path in paths:
            # Check for double slashes (allowing for leading /)
            assert "//" not in path[1:], f"{path} contains double slashes"


class TestS3PathsEdgeCases:
    """Test edge cases and special scenarios."""

    def test_paths_are_strings_not_bytes(self):
        """Test that all paths are strings, not bytes."""
        p = S3Paths()
        paths = [
            p.head_bucket(),
            p.day(),
            p.landing(),
            p.accounts_json(),
            p.billing_documents_json(),
            p.billing_lines_json(),
            p.payments_json(),
            p.rentals_json(),
            p.subscriptions_json(),
        ]
        for path in paths:
            assert isinstance(path, str), f"{path} is not a string but {type(path)}"

    def test_paths_are_not_empty(self):
        """Test that all paths are not empty strings."""
        p = S3Paths()
        paths = [
            p.head_bucket(),
            p.day(),
            p.landing(),
            p.accounts_json(),
            p.billing_documents_json(),
            p.billing_lines_json(),
            p.payments_json(),
            p.rentals_json(),
            p.subscriptions_json(),
        ]
        for path in paths:
            assert len(path) > 0, "Path is empty"


class TestS3PathsStaticMethods:
    """Test that methods are properly static and callable."""

    def test_head_bucket_is_callable(self):
        """Test that head_bucket is callable."""
        assert callable(S3Paths.head_bucket)

    def test_day_is_callable(self):
        """Test that day is callable."""
        assert callable(S3Paths.day)

    def test_landing_is_callable(self):
        """Test that landing is callable."""
        assert callable(S3Paths.landing)

    def test_accounts_json_is_callable(self):
        """Test that accounts_json is callable."""
        assert callable(S3Paths.accounts_json)

    @patch('tfl.aws.s3.paths.datetime')
    def test_all_methods(self, mock_datetime):

        # Mock datetime.now().strftime('%Y-%m-%d') to return a fixed date
        mock_datetime.now.return_value = datetime.strptime("2024-12-30", "%Y-%m-%d")

        paths = S3Paths(refresh=True)

        print(paths.day())

        assert eq(paths.head_bucket(), "tfl-financial-engin-data-days")
        assert eq(paths.day(), "2024-12-29")
        assert eq(paths.landing(), "2024-12-29/landing")
        assert eq(paths.accounts_json(), "2024-12-29/landing/accounts.json")
        assert eq(paths.billing_documents_json(), "2024-12-29/landing/billingdocuments.json")
        assert eq(paths.billing_lines_json(), "2024-12-29/landing/billinglines.json")
        assert eq(paths.payments_json(), "2024-12-29/landing/payments.json")
        assert eq(paths.rentals_json(), "2024-12-29/landing/rentals.json")
        assert eq(paths.subscriptions_json(), "2024-12-29/landing/subscriptions.json")
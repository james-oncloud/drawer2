from __future__ import annotations

import json

import pytest
from botocore.exceptions import BotoCoreError, ClientError

# Import the in-memory test store from the test-local implementation
from s3_store import InMemoryS3Store


@pytest.mark.integration
class TestS3IntegrationWithLocalStack:
    region_name = "eu-west-2"

    bucket_prefix = "integration-bucket"
    import uuid
    from datetime import datetime

    bucket_name = (
        f"{bucket_prefix}-{uuid.uuid4().hex[:8]}-{datetime.now().strftime('%Y-%m-%d-%H%M%S')}"
    )

    key = "data-files/data.json"
    payload = {"name": "james"}
    json_bytes = json.dumps(payload).encode("utf-8")

    def setup_method(self) -> None:
        # self._remove_existing_integration_buckets()
        self.store = InMemoryS3Store(bucket=self.bucket_name)

    def teardown_method(self) -> None:
        try:
            response = self.client.list_objects_v2(Bucket=self.bucket_name)
            for obj in response.get("Contents", []):
                self.client.delete_object(Bucket=self.bucket_name, Key=obj["Key"])
            self.client.delete_bucket(Bucket=self.bucket_name)
        except (ClientError, BotoCoreError):
            # Best-effort cleanup for already removed resources.
            pass
        finally:
            self._endpoint_ctx.__exit__(None, None, None)

    def _remove_existing_integration_buckets(self) -> None:
        response = self.client.list_buckets()
        for bucket in response.get("Buckets", []):
            bucket_name = bucket.get("Name", "")
            if bucket_name.startswith(self.bucket_prefix):
                self._delete_bucket_and_contents(bucket_name)

    def _delete_bucket_and_contents(self, bucket_name: str) -> None:
        continuation_token = None
        while True:
            params = {"Bucket": bucket_name}
            if continuation_token is not None:
                params["ContinuationToken"] = continuation_token
            response = self.client.list_objects_v2(**params)
            for obj in response.get("Contents", []):
                self.client.delete_object(Bucket=bucket_name, Key=obj["Key"])
            if not response.get("IsTruncated"):
                break
            continuation_token = response.get("NextContinuationToken")
        self.client.delete_bucket(Bucket=bucket_name)

    def test_s3_read_write_round_trip_in_mem(self) -> None:

            try:
                self.store.write_bytes(
                    self.key,
                    self.json_bytes,
                    content_type="text/plain",
                    metadata={"source": "integration"},
                )

                assert self.store.exists(self.key) is True
                assert self.store.read_bytes(self.key) == self.json_bytes

                # store.delete(self.key)
                # assert store.exists(self.key) is False
            except (ClientError, BotoCoreError) as error:
                pytest.fail(f"LocalStack S3 integration failed: {error}")

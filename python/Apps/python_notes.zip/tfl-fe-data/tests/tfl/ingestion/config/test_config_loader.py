
import json
import pytest
from unittest.mock import patch
from pydantic import ValidationError

import tfl.ingestion.config.bss_table_list_modul as config_loader  # contains load, Config, etc.


class FakePath:
    """
    Minimal fake "Traversable" object returned by importlib.resources.files(pkg) / 'file'
    that supports .read_text(encoding=...).
    """
    def __init__(self, text: str):
        self._text = text

    def read_text(self, encoding="utf-8"):
        return self._text

    # The loader uses `files(pkg) / "BssTableList.json"`
    def __truediv__(self, other: str):
        return self


def _mock_files_to_return(text: str):
    """
    Factory that returns a function to replace importlib.resources.files,
    so files('tfl.config') / 'BssTableList.json' -> FakePath(text)
    """
    def _files(pkg: str):
        assert pkg == "tfl.config"
        return FakePath(text)
    return _files


def test_load_happy_path():
    payload = {
        "dimensions": [
            {"name": "TimeDim", "sql": "GetTimeDim"},
            {"name": "DateDim", "sql": "GetDateDim"},
        ],
        "facts": [{"name": "Payments", "sql": "GetBikePayments_Cards"}],
        "settings": {"parallelBatchSize": 5, "sqlFolder": "bss_lyft"},
    }
    text = json.dumps(payload)

    #Patch the symbol where it is *looked up* by the code under test
    with patch.object(config_loader, "files", _mock_files_to_return(text)):
        cfg = config_loader.load()

    assert isinstance(cfg, config_loader.Config)
    assert isinstance(cfg.settings, config_loader.Settings)
    assert cfg.settings.parallelBatchSize == 5
    assert cfg.settings.sqlFolder == "bss_lyft"
    assert len(cfg.dimensions) == 2
    assert isinstance(cfg.dimensions[0], config_loader.Dimension)
    assert cfg.dimensions[0].name == "TimeDim"
    assert cfg.dimensions[0].sql == "GetTimeDim"
    assert len(cfg.facts) == 1
    assert isinstance(cfg.facts[0], config_loader.Fact)
    assert cfg.facts[0].name == "Payments"
    assert cfg.facts[0].sql == "GetBikePayments_Cards"


def test_load_invalid_json():
    # malformed JSON (missing closing brace)
    bad_text = (
        '{"dimensions":[{"name":"A","sql":"Q"}],"facts":[],"settings":{"parallelBatchSize":5,"sqlFolder":"X" }'
    )
    with patch.object(config_loader, "files", _mock_files_to_return(bad_text)):
        with pytest.raises(json.JSONDecodeError):
            config_loader.load()


def test_load_schema_validation_error_missing_settings():
    text = json.dumps(
        {
            "dimensions": [{"name": "A", "sql": "Q"}],
            "facts": [{"name": "B", "sql": "W"}],
            # "settings": {...}  # intentionally missing
        }
    )
    with patch.object(config_loader, "files", _mock_files_to_return(text)):
        with pytest.raises(ValidationError):
            config_loader.load()


def test_load_schema_validation_error_wrong_types():
    text = json.dumps(
        {
            "dimensions": [{"name": "A", "sql": "Q"}],
            "facts": [{"name": "B", "sql": "W"}],
            "settings": {"parallelBatchSize": "not-an-int", "sqlFolder": "bss_lyft"},
        }
    )
    with patch.object(config_loader, "files", _mock_files_to_return(text)):
        with pytest.raises(ValidationError):
            config_loader.load()


def test_load_file_not_found():
    class NotFoundFakePath(FakePath):
        def read_text(self, encoding="utf-8"):
            raise FileNotFoundError("BssTableList.json not found")

    def _files(_pkg):
        return NotFoundFakePath("")

    with patch.object(config_loader, "files", _files):
        with pytest.raises(FileNotFoundError):
            config_loader.load()
import json
import pytest
from unittest.mock import patch
from pydantic import ValidationError

# Import the module under test
import tfl.ingestion.config.sage_bss_table_list_modul as modul


class FakePath:
    """
    Minimal fake "Traversable" object returned by importlib.resources.files(pkg) / 'file'
    that supports .read_text(encoding=...).
    """
    def __init__(self, text: str):
        self._text = text

    def read_text(self, encoding="utf-8"):
        return self._text

    # The loader uses `files(pkg) / "SageBssTableList.json"`
    def __truediv__(self, other: str):
        return self


def _mock_files_to_return(text: str):
    """
    Factory that returns a function to replace importlib.resources.files,
    so files('tfl.config') / 'SageBssTableList.json' -> FakePath(text)
    """
    def _files(pkg: str):
        assert pkg == "tfl.ingestion.config"
        return FakePath(text)
    return _files


def test_load_bss_table_list_happy_path():
    payload = {
        "dimensions": [
            {"name": "SubscriptionTypeDim", "sql": "GetSubscriptionTypeDim"},
            {"name": "TaxRateDim", "sql": "GetTaxRateDim"},
            {"name": "CorporateProgramDim", "sql": "GetCorporateProgramDim"},
            {"name": "BikeDim", "sql": "GetBikeDim"},
            {"name": "DiscountCodeFact", "sql": "GetDiscountCodeFact"},
            {"name": "BusinessDocumentTypeDim", "sql": "GetBusinessDocumentTypeDim"}
        ]
    }
    text = json.dumps(payload)

    # Patch the symbol where it is looked up by the code under test
    with patch('tfl.ingestion.config.sage_bss_table_list_modul.files', side_effect=_mock_files_to_return(text)):
        cfg = modul.load()

    # Assert the result
    assert isinstance(cfg, modul.Config)
    assert len(cfg.dimensions) == 6
    assert cfg.dimensions[0].name == "SubscriptionTypeDim"
    assert cfg.dimensions[0].sql == "GetSubscriptionTypeDim"
    assert cfg.dimensions[5].name == "BusinessDocumentTypeDim"
    assert cfg.dimensions[5].sql == "GetBusinessDocumentTypeDim"


def test_load_bss_table_list_invalid_json():
    invalid_text = "{ invalid json }"

    with patch('tfl.ingestion.config.sage_bss_table_list_modul.files', side_effect=_mock_files_to_return(invalid_text)):
        with pytest.raises(json.JSONDecodeError):
            modul.load()


def test_load_bss_table_list_invalid_config():
    payload = {
        "dimensions": [
            {"name": "TestDim"}  # Missing 'sql'
        ]
    }
    text = json.dumps(payload)

    with patch('tfl.ingestion.config.sage_bss_table_list_modul.files', side_effect=_mock_files_to_return(text)):
        with pytest.raises(ValidationError) as exc_info:
            modul.load()
    assert "sql" in str(exc_info.value)
from tfl.core.service import build_message


def test_build_message_with_name() -> None:
    assert build_message("James") == "Hello, James!"


def test_build_message_defaults_world_on_whitespace() -> None:
    assert build_message("   ") == "Hello, World!"

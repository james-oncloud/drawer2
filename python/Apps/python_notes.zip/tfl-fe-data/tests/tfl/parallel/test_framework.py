import time

from tfl.ingestion.parallel.framework_modul import ParallelProcessor, Task


def multiply(value: int, factor: int) -> int:
    return value * factor


def sleeper(duration: float, value: int) -> int:
    time.sleep(duration)
    return value


def always_fails() -> None:
    raise RuntimeError("intentional failure")


def test_run_tasks_returns_results_in_input_order() -> None:
    processor = ParallelProcessor(max_workers=3)
    tasks = [
        Task(func=multiply, args=(2, 5)),
        Task(func=multiply, args=(4, 3)),
        Task(func=multiply, args=(7, 2)),
    ]

    results = processor.run_tasks(tasks)

    assert [result.value for result in results] == [10, 12, 14]
    assert all(result.error is None for result in results)


def test_run_tasks_captures_exceptions() -> None:
    processor = ParallelProcessor(max_workers=2)
    tasks = [
        Task(func=multiply, args=(3, 3)),
        Task(func=always_fails),
    ]

    results = processor.run_tasks(tasks)

    assert results[0].value == 9
    assert results[0].error is None
    assert results[1].value is None
    assert isinstance(results[1].error, RuntimeError)
    assert str(results[1].error) == "intentional failure"


def test_run_tasks_empty_input_returns_empty_list() -> None:
    processor = ParallelProcessor()
    assert processor.run_tasks([]) == []


def test_tasks_execute_in_parallel() -> None:
    processor = ParallelProcessor(max_workers=2)
    tasks = [
        Task(func=sleeper, args=(0.4, 1)),
        Task(func=sleeper, args=(0.4, 2)),
    ]

    started = time.perf_counter()
    results = processor.run_tasks(tasks)
    elapsed = time.perf_counter() - started

    assert [result.value for result in results] == [1, 2]
    # Sequential runtime would be about 0.8s. Parallel should stay well below that.
    assert elapsed < 0.7

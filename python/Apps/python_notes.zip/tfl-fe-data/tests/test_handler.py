import json

from tfl.handler import lambda_handler_hello


def test_lambda_handler_returns_expected_payload() -> None:
    response = lambda_handler_hello({"name": "James"}, context=None)

    assert response["statusCode"] == 200
    assert response["headers"]["Content-Type"] == "application/json"
    assert json.loads(response["body"]) == {"message": "Hello, James!"}


def test_lambda_handler_defaults_world_when_name_missing() -> None:
    response = lambda_handler_hello({}, context=None)
    assert json.loads(response["body"]) == {"message": "Hello, World!"}


def test_lambda_handler_coerces_non_string_names() -> None:
    response = lambda_handler_hello({"name": 123}, context=None)
    assert json.loads(response["body"]) == {"message": "Hello, 123!"}

"""Pytest configuration and fixtures for test suite."""
import sys
from pathlib import Path

# Ensure src directory is on sys.path for imports to work correctly
project_root = Path(__file__).parent.parent
src_path = project_root / "src"
if str(src_path) not in sys.path:
    sys.path.insert(0, str(src_path))